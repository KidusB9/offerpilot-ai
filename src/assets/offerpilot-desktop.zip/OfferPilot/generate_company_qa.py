"""
generate_company_qa.py — build a company-tailored interview Q&A database.
=========================================================================

Given a COMPANY name and a ROLE, this produces the exact same JSON schema the
Interview Copilot already loads, so the copilot can be pointed at any company:

    <slug>_qa.json       {"company","role","stack",
                           "questions":[{section,question,answer,code,lang,keywords}]}
    <slug>_profile.json  {"company","role","system_prompt"}

It tries the LIVE AI backends first (the SAME keys / model names / endpoints the
copilot uses — Grok on api.x.ai, DeepSeek, Gemini), asking each for STRICT JSON
in that schema, then parses and validates it. If every backend fails (no network,
bad key, quota) it falls back to a solid built-in template so a file is ALWAYS
written.

Programmatic use:
    from generate_company_qa import generate
    qa_path, profile_path = generate("Google", "Software Engineer", out_dir=".")

CLI:
    python generate_company_qa.py "Google" "Software Engineer"
    python generate_company_qa.py                 # prompts for company + role
"""

import os
import re
import sys
import json

import requests


# --------------------------------------------------------------------------- #
#  API KEYS + MODELS  (copied verbatim from interview_copilot.py so the         #
#  generator hits the exact same backends the copilot streams from)            #
# --------------------------------------------------------------------------- #
from offerpilot_keys import GROK_API_KEY, DEEPSEEK_API_KEY, GEMINI_API_KEY

GROK_MODEL = "grok-4-fast-reasoning"
DEEPSEEK_MODEL = "deepseek-chat"
GEMINI_MODEL = "gemini-2.5-flash"

GROK_URL = "https://api.x.ai/v1/chat/completions"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"


# --------------------------------------------------------------------------- #
#  HELPERS                                                                      #
# --------------------------------------------------------------------------- #
def _script_dir():
    return os.path.dirname(os.path.abspath(__file__))


def slugify(name):
    """"JPMorgan Chase" -> "jpmorgan-chase" (matches the copilot's qa filenames)."""
    s = (name or "").strip().lower()
    s = re.sub(r"[^\w\s-]", "", s)      # drop punctuation
    s = re.sub(r"[\s_]+", "-", s)       # spaces / underscores -> hyphen
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "company"


def build_system_prompt(company, role):
    """A company-tailored real-time co-pilot prompt, modeled on interview_copilot's
    SYSTEM_PROMPT but parameterized by company + role."""
    return (
        f"You are the real-time interview co-pilot for KIDUS BERHAN during a live "
        f"{company} '{role}' interview. The user message is a LIVE transcription of "
        f"the interviewer and may contain small transcription errors.\n\n"
        "Do this:\n"
        "1. Infer the actual question being asked.\n"
        "2. Write a first-person answer KIDUS can say OUT LOUD immediately — confident, "
        "concrete, in his voice. Ground it in his background and the REFERENCE answers "
        "provided (Computer Science, 4.0 GPA at Bradley; 2+ years as a C#/.NET / Postgres "
        "engineer at Universal Engineering Sciences; the UROCK platform — offline-first "
        "sync, Azure DevOps CI/CD, 35-office rollout; on-prem AI services; an OSF "
        f"HealthCare data-science co-op) and tailor it to {company} and the {role} role.\n"
        "3. If code is expected, output the OPTIMAL solution — best possible time and "
        "space complexity — inside a fenced code block (```csharp / ```python / ```sql / "
        "```java as fits the role), and explicitly state its Big-O time AND space "
        "complexity right after the code, plus one line on why it's optimal (the key "
        "insight / data structure).\n\n"
        "Output ONLY the answer. No 'what they're testing', no coaching, no preamble. "
        "Keep it tight and speakable."
    )


# --------------------------------------------------------------------------- #
#  LIVE AI GENERATION                                                           #
# --------------------------------------------------------------------------- #
def _generation_messages(company, role):
    schema_hint = (
        '{"questions":[{"section":"...","question":"...","answer":"...",'
        '"code":"...","lang":"csharp","keywords":["...","..."]}]}'
    )
    system = (
        "You generate realistic interview-preparation databases as STRICT JSON. "
        "You output ONLY a single JSON object and nothing else — no markdown fence, "
        "no commentary."
    )
    user = (
        f"Build an interview Q&A database for a candidate (Kidus Berhan, a C#/.NET "
        f"engineer with an offline-sync platform, on-prem AI, and healthcare-data "
        f"background) interviewing at {company} for the role '{role}'.\n\n"
        "Return a JSON object of the EXACT shape:\n"
        f"{schema_hint}\n\n"
        "Rules:\n"
        "- 7 to 9 question objects.\n"
        "- Cover these sections in order: 'Opening', 'Behavioral (STAR)', "
        "'Fundamentals', 'Coding' (1 or 2 items, each WITH a real code solution in "
        "the `code` field and its language in `lang`), 'System / Domain', 'Closing'.\n"
        "- `answer` is a first-person answer Kidus can say out loud, grounded in his "
        "background and tailored to the company/role.\n"
        "- For non-coding items set `code` to an empty string and `lang` to \"csharp\".\n"
        "- `keywords` is 3-6 lowercase match terms.\n"
        "- Valid JSON only: double-quoted keys/strings, escaped newlines in code.\n"
        "Return ONLY the JSON object."
    )
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def _openai_json(url, model, key, messages):
    """Non-streaming OpenAI-compatible call (Grok / DeepSeek) -> raw text content."""
    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.4,
        "max_tokens": 4000,
        "stream": False,
        "response_format": {"type": "json_object"},
    }
    r = requests.post(url, json=payload, timeout=(10, 120),
                      headers={"Authorization": f"Bearer {key}",
                               "Content-Type": "application/json"})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]


def _gemini_json(messages):
    """Non-streaming Gemini call -> raw text content."""
    system, contents = "", []
    for m in messages:
        if m["role"] == "system":
            system = m["content"]
            continue
        contents.append({"role": "user", "parts": [{"text": m["content"]}]})
    if system and contents:
        contents[0]["parts"][0]["text"] = f"System Instruction: {system}\n\n" + contents[0]["parts"][0]["text"]
    payload = {"contents": contents,
               "generationConfig": {"temperature": 0.3, "maxOutputTokens": 4000,
                                     "responseMimeType": "application/json"}}
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}")
    r = requests.post(url, json=payload, timeout=(10, 120),
                      headers={"Content-Type": "application/json"})
    if r.status_code in (403, 429):
        raise Exception(f"Gemini {r.status_code} (quota/permission).")
    r.raise_for_status()
    parts = r.json()["candidates"][0].get("content", {}).get("parts", [])
    return "".join(p.get("text", "") for p in parts)


def _extract_json(text):
    """Pull a JSON object out of a model reply that may be fenced or chatty."""
    if not text:
        return None
    t = text.strip()
    # strip a leading ```json / ``` fence if present
    m = re.search(r"```(?:json)?\s*(.*?)```", t, flags=re.S)
    if m:
        t = m.group(1).strip()
    # otherwise clip to the outermost { ... }
    if not t.startswith("{"):
        i, j = t.find("{"), t.rfind("}")
        if i != -1 and j != -1 and j > i:
            t = t[i:j + 1]
    try:
        return json.loads(t)
    except Exception:
        return None


def _validate_and_clean(data):
    """Coerce a parsed reply into the strict schema; return a clean questions list
    or None if it isn't usable."""
    if not isinstance(data, dict):
        return None
    qs = data.get("questions")
    if not isinstance(qs, list) or not qs:
        return None
    clean = []
    for it in qs:
        if not isinstance(it, dict):
            continue
        q = str(it.get("question", "")).strip()
        a = str(it.get("answer", "")).strip()
        if not q or not a:
            continue
        clean.append({
            "section": str(it.get("section", "")).strip() or "General",
            "question": q,
            "answer": a,
            "code": str(it.get("code", "") or "").strip(),
            "lang": (str(it.get("lang", "") or "csharp").strip() or "csharp").lower(),
            "keywords": [str(k).strip().lower() for k in it.get("keywords", [])
                         if str(k).strip()][:6],
        })
    return clean if len(clean) >= 4 else None


def generate_via_ai(company, role):
    """Try each live backend in turn; return a clean questions list or None."""
    messages = _generation_messages(company, role)
    backends = [
        ("Grok", lambda: _openai_json(GROK_URL, GROK_MODEL, GROK_API_KEY, messages)),
        ("DeepSeek", lambda: _openai_json(DEEPSEEK_URL, DEEPSEEK_MODEL, DEEPSEEK_API_KEY, messages)),
        ("Gemini", lambda: _gemini_json(messages)),
    ]
    for name, call in backends:
        try:
            print(f"[generate] asking {name}…")
            raw = call()
            clean = _validate_and_clean(_extract_json(raw))
            if clean:
                print(f"[generate] {name} produced {len(clean)} questions.")
                return clean
            print(f"[generate] {name} returned unusable JSON; trying next.")
        except Exception as e:
            print(f"[generate] {name} failed: {e}")
    return None


# --------------------------------------------------------------------------- #
#  BUILT-IN FALLBACK TEMPLATE  (always available, offline)                      #
# --------------------------------------------------------------------------- #
def fallback_questions(company, role):
    """A solid 8-question set in Kidus's voice, parameterized by company/role, so a
    file is produced even with no network / bad keys."""
    return [
        {
            "section": "Opening",
            "question": "Tell me about yourself. / Walk me through your background.",
            "answer": (
                "I studied Computer Science at Bradley University and graduated with a 4.0 GPA. "
                "For the past two-plus years I've been a software engineer at Universal Engineering "
                "Sciences building enterprise applications in C# and .NET on a Postgres backend, with "
                "an Angular web front end and a React Native mobile app. My flagship project is UROCK, "
                "a platform we built to replace a third-party vendor system — I worked across the stack, "
                "owned a lot of the CI/CD in Azure DevOps, and rolled it out to 35 branch offices. More "
                "recently I've focused on AI-assisted engineering, including on-prem AI services with real "
                f"controls around sensitive data. I'm excited about {company} and the {role} role because "
                "I want to work where correctness, security, and resiliency matter at scale."
            ),
            "code": "",
            "lang": "csharp",
            "keywords": ["tell me about yourself", "background", "intro", "walk me through"],
        },
        {
            "section": "Opening",
            "question": f"Why {company}? / Why leave your current role?",
            "answer": (
                f"Two reasons. First, scale and impact — I've built platforms used across 35 offices, but "
                f"{company} operates at a level where the bar for correctness, resiliency, and security is on "
                "a different order, and I want to grow in that environment. Second, this role lines up directly "
                "with my C#/.NET and platform work and the ownership I've had. I'm not running away from UES — "
                "I've had real ownership there — I'm running toward higher engineering discipline, mentorship, "
                "and stakes."
            ),
            "code": "",
            "lang": "csharp",
            "keywords": [f"why {slugify(company).replace('-', ' ')}", "why leave", "motivation"],
        },
        {
            "section": "Behavioral (STAR)",
            "question": "Tell me about the most challenging technical project you've worked on.",
            "answer": (
                "The hardest was the offline-first data sync for our UROCK mobile app. Field inspectors work in "
                "zero-connectivity zones but still need to collect structured data that reliably reaches Postgres. "
                "I architected the mobile data layer so every record is written locally first, then reconciled with "
                "the server when connectivity returns. The hard part was conflict resolution for two people editing "
                "related records offline, so I designed a deterministic merge and a sync-queue with idempotent server "
                "writes so replays never create duplicates, backed by integration tests that simulated flaky networks. "
                "Result: about 40% better field data-collection efficiency in no-signal zones and essentially 100% data "
                "integrity on sync. The lesson: idempotency and safe retries aren't optional when the network can't be "
                "trusted."
            ),
            "code": "",
            "lang": "csharp",
            "keywords": ["challenging project", "hardest", "offline sync", "idempotency", "star"],
        },
        {
            "section": "Fundamentals",
            "question": "What's the difference between a value type and a reference type?",
            "answer": (
                "A value type holds its data directly — int, bool, double, structs — so assigning or passing copies "
                "the value. A reference type — classes, arrays, strings, delegates — holds a reference to an object on "
                "the managed heap, so assigning copies the reference and two variables can point at the same object. "
                "Value types typically live on the stack or inline in their container; reference-type objects live on "
                "the heap and are managed by the GC. The practical impact is copy semantics and allocation."
            ),
            "code": "",
            "lang": "csharp",
            "keywords": ["value type", "reference type", "stack", "heap", "clr"],
        },
        {
            "section": "Coding",
            "question": "Two Sum — return indices of the two numbers that add to a target.",
            "answer": (
                "I'll restate it and confirm assumptions (exactly one solution, no reusing an element), then reason "
                "about the optimal approach. Brute force is O(n²). The insight is a hash map from value to index: for "
                "each number, check if target − num is already seen in one pass. That's O(n) time, O(n) space. Dry-run "
                "[2,7,11,15], target 9 → at 7, 9−7=2 is in the map at index 0, return [0,1]."
            ),
            "code": (
                "public int[] TwoSum(int[] nums, int target) {\n"
                "    var seen = new Dictionary<int, int>();\n"
                "    for (int i = 0; i < nums.Length; i++) {\n"
                "        int need = target - nums[i];\n"
                "        if (seen.TryGetValue(need, out int j)) return new[] { j, i };\n"
                "        seen[nums[i]] = i;\n"
                "    }\n"
                "    return System.Array.Empty<int>();\n"
                "}\n"
                "// O(n) time, O(n) space — one pass, hash lookups are O(1) amortized."
            ),
            "lang": "csharp",
            "keywords": ["two sum", "hash map", "array", "coding", "complexity"],
        },
        {
            "section": "Coding",
            "question": "Detect a cycle in a linked list.",
            "answer": (
                "Floyd's tortoise and hare: advance one pointer by one and another by two; if they ever meet there's a "
                "cycle, if the fast pointer hits null there isn't. O(n) time, O(1) space — better than a hash set of "
                "visited nodes, which is O(n) space. Edge cases: an empty list and a single node with no cycle both "
                "return false."
            ),
            "code": (
                "public bool HasCycle(ListNode head) {\n"
                "    var slow = head; var fast = head;\n"
                "    while (fast != null && fast.next != null) {\n"
                "        slow = slow.next;\n"
                "        fast = fast.next.next;\n"
                "        if (slow == fast) return true;\n"
                "    }\n"
                "    return false;\n"
                "}\n"
                "// O(n) time, O(1) space."
            ),
            "lang": "csharp",
            "keywords": ["linked list", "cycle", "floyd", "two pointers"],
        },
        {
            "section": "System / Domain",
            "question": f"How would you design a reliable, correct core service for {company}?",
            "answer": (
                "I'd start from the invariants — what must always be true — and design for correctness first, then "
                "scale. I'd make every state-changing operation idempotent behind an idempotency key so retries are "
                "safe, keep a durable append-only log of intent so nothing is silently lost, and separate the fast "
                "read path from the write path. I'd add explicit timeouts, retries with backoff, and circuit breakers "
                "at every network boundary, and I'd instrument correctness with reconciliation jobs rather than trusting "
                "the happy path. That's the same offline-sync discipline from UROCK, applied at higher stakes: assume the "
                "network and downstream services fail, and make the system converge to a correct state anyway."
            ),
            "code": "",
            "lang": "csharp",
            "keywords": ["system design", "reliability", "idempotency", "resiliency", "domain"],
        },
        {
            "section": "Closing",
            "question": "Do you have any questions for us?",
            "answer": (
                "Yes — a few. How does this team measure a successful first 90 days for this role? What's the hardest "
                "reliability or correctness problem the platform is facing right now? And how do you balance shipping "
                "velocity against the security and controls the domain needs? I ask because the 'who is downstream of "
                "this' mindset is already how I think, and I want to understand where I'd plug into it."
            ),
            "code": "",
            "lang": "csharp",
            "keywords": ["questions for us", "closing", "culture"],
        },
    ]


# --------------------------------------------------------------------------- #
#  PUBLIC ENTRY POINT                                                           #
# --------------------------------------------------------------------------- #
def generate(company, role, out_dir="."):
    """Generate the Q&A DB + profile for (company, role) and write both files into
    out_dir. Returns (qa_path, profile_path). Always writes files (AI or fallback)."""
    company = (company or "").strip() or "Company"
    role = (role or "").strip() or "Software Engineer"
    out_dir = os.path.abspath(out_dir or ".")
    os.makedirs(out_dir, exist_ok=True)
    slug = slugify(company)

    questions = generate_via_ai(company, role)
    source = "live-ai"
    if not questions:
        print("[generate] all backends unavailable — using the built-in template.")
        questions = fallback_questions(company, role)
        source = "template"

    qa_doc = {
        "company": company,
        "role": role,
        "source": source,
        "questions": questions,
    }
    profile_doc = {
        "company": company,
        "role": role,
        "system_prompt": build_system_prompt(company, role),
    }

    qa_path = os.path.join(out_dir, f"{slug}_qa.json")
    profile_path = os.path.join(out_dir, f"{slug}_profile.json")
    with open(qa_path, "w", encoding="utf-8") as f:
        json.dump(qa_doc, f, ensure_ascii=False, indent=2)
    with open(profile_path, "w", encoding="utf-8") as f:
        json.dump(profile_doc, f, ensure_ascii=False, indent=2)

    print(f"[generate] wrote {qa_path}")
    print(f"[generate] wrote {profile_path}")
    return qa_path, profile_path


def _main():
    args = [a for a in sys.argv[1:]]
    if len(args) >= 2:
        company, role = args[0], args[1]
    elif len(args) == 1:
        company, role = args[0], ""
    else:
        company, role = "", ""
    if not company.strip():
        try:
            company = input("Company: ").strip()
        except EOFError:
            company = ""
    if not role.strip():
        try:
            role = input("Role: ").strip()
        except EOFError:
            role = ""
    qa_path, profile_path = generate(company, role, out_dir=_script_dir())
    print(f"\nGenerated:\n  {qa_path}\n  {profile_path}")


if __name__ == "__main__":
    _main()
