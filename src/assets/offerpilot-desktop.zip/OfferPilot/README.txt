OfferPilot AI - Desktop copilot
================================

1. Install Python 3.11+ (Windows 10 2004+ or 11 for full screen-share invisibility).
2. pip install -r requirements.txt
3. Copy offerpilot_keys.example.json to offerpilot_keys.json and paste your model keys.
   (Your keys stay on your machine. Get them from x.ai, deepseek.com, and Google AI Studio.)
4. For on-device transcription, download the Vosk small English model
   (vosk-model-small-en-us-0.15) and unzip it into this folder.
5. For coding-screen capture, install Tesseract OCR.

Run it:
  python company_launcher.py        Pick a company, generate its Q&A set, and launch the copilot.
  python interview_copilot.py       The interview copilot (JPMorgan-tuned reference build).
  python leet.py                    The coding copilot (Ctrl+Alt+S to capture a problem).

Hotkeys: hold M pause, hold P ghost mode, Ctrl+Alt+H hide/show, Ctrl+Alt+1/2/3 switch model.

OfferPilot is a preparation and accessibility tool. Use it within the rules of any assessment you take.
