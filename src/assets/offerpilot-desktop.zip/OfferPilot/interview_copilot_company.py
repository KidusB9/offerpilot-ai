"""
interview_copilot_company.py — the Interview Copilot, pointed at ANY company.
=============================================================================

This is the SAME real-time copilot as interview_copilot.py — on-device Vosk
streaming STT, WDA_EXCLUDEFROMCAPTURE screen-share invisibility (shield + warning
banner), Grok + DeepSeek + Gemini streamed in parallel, RAG grounding + the
auto-scrolling Q&A page, the M / P / Ctrl+Alt+1-3 / Ctrl+Alt+H hotkeys, the
resizable frame, and the crash supervisor — with ONLY three things swapped per
company:

    * which Q&A json it loads   -> <slug>_qa.json  (+ <slug>_qa_extra.json)
    * the window title          -> "<Company> Copilot"
    * the SYSTEM_PROMPT         -> from <slug>_profile.json

Everything else is REUSED from interview_copilot.py by importing it as `ic` and
monkey-patching only those three seams before the window is built. The original
interview_copilot.py is never modified.

The company SLUG comes from:
    argv[1]  ->  OFFERPILOT_COMPANY env var  ->  default "jpmorgan-chase"
For the default slug, if no jpmorgan-chase_qa.json exists it transparently falls
back to the existing interview_qa*.json so the original prep DB still works.

Run:
    python interview_copilot_company.py                 # jpmorgan-chase (default)
    python interview_copilot_company.py google
    set OFFERPILOT_COMPANY=stripe && python interview_copilot_company.py
"""

import os
import sys
import json

import interview_copilot as ic

from PyQt6.QtWidgets import QApplication, QLabel


# --------------------------------------------------------------------------- #
#  MODULE STATE  (the active company slug, read by the patched Knowledge)       #
# --------------------------------------------------------------------------- #
DEFAULT_SLUG = "jpmorgan-chase"
_SLUG = DEFAULT_SLUG


def _script_dir():
    return os.path.dirname(os.path.abspath(__file__))


def _bases():
    """Search cwd first, then next to this script (same order as ic.Knowledge)."""
    bases = []
    for b in (os.getcwd(), _script_dir(), ic._script_dir()):
        if b not in bases:
            bases.append(b)
    return bases


def _first_existing(names):
    for name in names:
        for base in _bases():
            p = os.path.join(base, name)
            if os.path.exists(p):
                return p
    return None


def resolve_slug():
    """argv[1] (ignoring the --child flag) -> OFFERPILOT_COMPANY -> default."""
    for a in sys.argv[1:]:
        if a == "--child" or a.startswith("-"):
            continue
        return _slugify(a)
    env = os.environ.get("OFFERPILOT_COMPANY", "").strip()
    if env:
        return _slugify(env)
    return DEFAULT_SLUG


def _slugify(name):
    # Accept either an already-slugged token ("goldman-sachs") or a display name.
    try:
        from generate_company_qa import slugify
        return slugify(name)
    except Exception:
        import re
        s = re.sub(r"[^\w\s-]", "", (name or "").strip().lower())
        s = re.sub(r"[\s_]+", "-", s)
        return re.sub(r"-+", "-", s).strip("-") or DEFAULT_SLUG


# --------------------------------------------------------------------------- #
#  COMPANY KNOWLEDGE  (reuses ic.Knowledge; only the file names change)         #
# --------------------------------------------------------------------------- #
class CompanyKnowledge(ic.Knowledge):
    """Loads <slug>_qa.json / <slug>_qa_extra.json instead of the hard-coded
    interview_qa*.json. Falls back to interview_qa*.json for the default slug so
    the original prep DB keeps working out of the box. Everything else (matching,
    RAG retrieve, build_html) is inherited unchanged."""

    def _load(self):
        names = [f"{_SLUG}_qa.json", f"{_SLUG}_qa_extra.json"]
        for name in names:
            p = _first_existing([name])
            if p:
                self._load_file(p)
        if not self.items and _SLUG == DEFAULT_SLUG:
            # Back-compat: fall back to the original copilot's prep DB.
            for name in ("interview_qa.json", "interview_qa_extra.json"):
                p = _first_existing([name])
                if p:
                    self._load_file(p)
        if not self.items:
            print(f"No {_SLUG}_qa.json found (generate one with generate_company_qa.py).")
        else:
            print(f"Loaded {len(self.items)} Q&A entries for '{_SLUG}'.")


# --------------------------------------------------------------------------- #
#  PROFILE  (company / role / system_prompt)                                    #
# --------------------------------------------------------------------------- #
def load_profile(slug):
    """Read <slug>_profile.json; return (company, role, system_prompt) with sane
    fallbacks if it's missing or malformed."""
    company = slug.replace("-", " ").title()
    role = "Software Engineer"
    system_prompt = None
    p = _first_existing([f"{slug}_profile.json"])
    if p:
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            company = (data.get("company") or company).strip()
            role = (data.get("role") or role).strip()
            sp = (data.get("system_prompt") or "").strip()
            if sp:
                system_prompt = sp
        except Exception as e:
            print(f"Failed to read {p}: {e}")
    if not system_prompt:
        # Build one on the fly (or fall back to the original prompt).
        try:
            from generate_company_qa import build_system_prompt
            system_prompt = build_system_prompt(company, role)
        except Exception:
            system_prompt = ic.SYSTEM_PROMPT
    return company, role, system_prompt


# --------------------------------------------------------------------------- #
#  MAIN  (mirrors ic.main, but patches the three company seams first)          #
# --------------------------------------------------------------------------- #
def _retitle(win, company):
    """Swap the custom title-bar label + the native window title to the company."""
    win.setWindowTitle(f"{company} Interview Copilot")
    try:
        for lbl in win.title_bar.findChildren(QLabel):
            if "Interview Copilot" in lbl.text():
                lbl.setText(f"🎧  {company} Copilot")
                break
    except Exception:
        pass


def main(slug):
    global _SLUG
    _SLUG = slug
    company, role, system_prompt = load_profile(slug)

    # ---- the only three overrides ---- #
    ic.Knowledge = CompanyKnowledge     # which qa json loads (via Copilot.__init__)
    ic.SYSTEM_PROMPT = system_prompt     # company-tailored prompt (read in process())

    app = QApplication(sys.argv)
    win = ic.Copilot()                   # everything else is the untouched copilot
    _retitle(win, company)               # the window title
    win.show()
    print(f"Interview Copilot launched for '{company}' ({role}) [slug: {slug}].")
    return app.exec()


def _supervise(slug):
    """Run the app as a child process and relaunch it if it crashes (same pattern
    as interview_copilot.py, but the slug is passed through to the child)."""
    import time
    import subprocess
    fails = 0
    while True:
        started = time.monotonic()
        rc = subprocess.run(
            [sys.executable, os.path.abspath(__file__), slug, "--child"]).returncode
        if rc == 0:
            break  # clean exit (user closed / Esc)
        ran = time.monotonic() - started
        fails = fails + 1 if ran < 5 else 0
        if fails >= 5:
            print("Interview Copilot crashed 5x in a row — stopping. See the error above.")
            break
        print(f"\n⚠ Interview Copilot exited (code {rc}); restarting…\n")


if __name__ == "__main__":
    _slug = resolve_slug()
    if "--child" in sys.argv:
        import traceback
        try:
            sys.exit(main(_slug))
        except Exception:
            traceback.print_exc()
            sys.exit(1)
    else:
        _supervise(_slug)
