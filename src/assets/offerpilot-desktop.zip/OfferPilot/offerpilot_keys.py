"""Loads model API keys from environment variables or offerpilot_keys.json.
Your keys never leave your machine. Order: env var, then offerpilot_keys.json."""
import os, json

_KEYS = {}
_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "offerpilot_keys.json")
try:
    with open(_path, "r", encoding="utf-8") as _f:
        _KEYS = json.load(_f) or {}
except Exception:
    _KEYS = {}

def _k(name):
    return os.environ.get(name) or _KEYS.get(name, "")

GROK_API_KEY = _k("GROK_API_KEY")
DEEPSEEK_API_KEY = _k("DEEPSEEK_API_KEY")
GEMINI_API_KEY = _k("GEMINI_API_KEY")
