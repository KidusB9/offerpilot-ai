# Company Interview Copilot — select · generate · launch

A thin flow on top of the existing Interview Copilot that lets you point it at
**any company**: pick a company, auto-generate a tailored Q&A database, and launch
the real-time copilot grounded in it — without touching the original apps.

## What's here (all new files)

| File | What it does |
|------|--------------|
| `company_launcher.py` | PyQt6 launcher: ~10 company buttons + free-text **Company** / **Role** + **Generate & Launch**. |
| `generate_company_qa.py` | Module + CLI. Builds `<slug>_qa.json` and `<slug>_profile.json` in the copilot's schema. |
| `interview_copilot_company.py` | The full Interview Copilot, pointed at one company's slug. |

The existing apps — `interview_copilot.py`, `neuberger_copilot.py`, `leet.py` —
are **not modified**. `interview_copilot_company.py` imports `interview_copilot`
and overrides only three seams (which Q&A file loads, the window title, and the
SYSTEM_PROMPT); everything else is reused unchanged.

## Quick start

```bash
python company_launcher.py
```

Click a company (e.g. **Google**), or type a **Company** and **Role**, then
**Generate & Launch**. The status line shows `Generating…` then `Launching…`.

### Generate only (CLI)

```bash
python generate_company_qa.py "Stripe" "Software Engineer"
python generate_company_qa.py            # prompts for Company + Role
```

### Launch only (a slug already generated)

```bash
python interview_copilot_company.py stripe
# or
set OFFERPILOT_COMPANY=stripe && python interview_copilot_company.py
```

The company **slug** is the lowercased, hyphenated name: `JPMorgan Chase` →
`jpmorgan-chase`, `Goldman Sachs` → `goldman-sachs`. With no argument the copilot
defaults to `jpmorgan-chase`, and if no `jpmorgan-chase_qa.json` exists it falls
back to the original `interview_qa*.json` prep DB.

## What gets generated

For each company two files are written **next to the scripts**:

- `<slug>_qa.json` — `{ "company", "role", "questions": [ { section, question, answer, code, lang, keywords } ] }`
  — the exact schema the copilot loads (same as `web/src/data/qa/jpmorgan-chase.json`).
- `<slug>_profile.json` — `{ "company", "role", "system_prompt" }` — the company-tailored
  real-time prompt the copilot uses to ground answers.

Generation tries the **live AI backends first** (Grok on `api.x.ai`, DeepSeek,
Gemini — the same keys/models the copilot streams from), asking for STRICT JSON,
then validates it. If the network or keys fail, it falls back to a solid built-in
template (Opening, Behavioral STAR, Fundamentals, two Coding items with code,
System/Domain, Closing) so a usable file is **always** written.

## The copilot itself (unchanged behavior)

Once launched it's the full Interview Copilot:

- On-device **Vosk** streaming STT (offline; never blocks Zoom/Teams).
- **Screen-share invisibility** via `WDA_EXCLUDEFROMCAPTURE` (green shield when ON,
  amber/red warning banner if only partial or failed). The launcher window is
  protected the same way.
- **Grok + DeepSeek + Gemini** streamed in parallel, RAG-grounded in the generated
  Q&A, with the auto-scrolling prepared-answer page.
- Hotkeys: hold **M** pause/resume, hold **P** ghost transparency,
  **Ctrl+Alt+1/2/3** switch model, **Ctrl+Alt+H** hide/show, **Esc** quit;
  resizable frame; crash-supervisor that self-restarts (`--child` pattern).

## Requirements

- **Python** with `PyQt6`, `requests`, `numpy`, `sounddevice`, `vosk`, `keyboard`,
  `rapidfuzz` (and optionally `pygments` for syntax-highlighted code).
- The **Vosk model** folder `vosk-model-small-en-us-0.15` next to the scripts.
- Network + valid API keys for live AI generation and streaming (generation still
  works offline via the built-in template; the copilot needs keys for answers).
- Windows 10 version 2004+ for full screen-capture exclusion.

## Honest note

This tool is for **interview prep and accessibility** — rehearsing answers in your
own voice and having your own notes surface quickly. Only use it within the rules
of any given assessment. If an interview or test forbids outside assistance, don't
use it there. Be honest about what you actually know and can do.
