import sys
import os
import ctypes
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from PIL import Image, ImageEnhance
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QRubberBand, QLineEdit, QLabel
from PyQt6.QtCore import Qt, pyqtSignal, QObject, QPoint, QRect, QSize, QRegularExpression, QByteArray, QBuffer, QIODevice, QTimer
from PyQt6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor, QCursor, QGuiApplication, QImage, QPainter, QPixmap
import keyboard
import requests
from io import BytesIO
import json
import speech_recognition as sr
import time
import base64
import pytesseract
from rapidfuzz import process, fuzz
import re
from offerpilot_keys import GROK_API_KEY, DEEPSEEK_API_KEY, GEMINI_API_KEY



print("Importing modules completed")

# --- Screen-share / screen-capture invisibility (Windows) ---------------------
# SetWindowDisplayAffinity lets a top-level window opt out of screen capture.
#   WDA_EXCLUDEFROMCAPTURE (0x11): the window is completely excluded from any
#       capture (Zoom, Teams, Meet, Discord, OBS, Snip, PrintScreen, etc.) yet
#       stays fully visible on the user's own physical monitor. Requires Windows
#       10 version 2004 (build 19041) or newer.
#   WDA_MONITOR (0x01): fallback for older builds - the window still can't be
#       captured, but it appears as a solid black rectangle in the capture.
WDA_NONE = 0x00000000
WDA_MONITOR = 0x00000001
WDA_EXCLUDEFROMCAPTURE = 0x00000011

def exclude_from_capture(widget):
    """Make a Qt widget's top-level window invisible to screen capture on Windows.

    Safe to call repeatedly (e.g. from showEvent or a timer) - it is idempotent
    and does not log, so the caller can re-assert it cheaply for self-healing.
    Returns one of:
        "excluded" - fully hidden from capture (WDA_EXCLUDEFROMCAPTURE)
        "monitor"  - fallback: window shows as a solid BLACK BOX in captures
        "failed"   - no protection applied; the window IS capturable
    """
    if sys.platform != "win32":
        return "failed"
    try:
        hwnd = int(widget.winId())
    except Exception:
        return "failed"
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        # BOOL is a 4-byte int; use c_int and test != 0 to match the Win32 contract.
        user32.SetWindowDisplayAffinity.restype = ctypes.c_int
        user32.SetWindowDisplayAffinity.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        # Prefer full exclusion (Win10 2004+); fall back to black-out on older builds.
        if user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE) != 0:
            return "excluded"
        if user32.SetWindowDisplayAffinity(hwnd, WDA_MONITOR) != 0:
            return "monitor"
        return "failed"
    except Exception:
        return "failed"

# Load local knowledge base
try:
    with open('knowledge.json', 'r') as f:
        knowledge = json.load(f)
    # Assume structure: {"problems": [{"title": "...", "solution": "...", "approach": "..."}]}
    def preprocess(text):
        return re.sub(r'[^\w\s]', '', text.lower())
    searchable_texts = []
    for p in knowledge.get('problems', []):
        text = p['title']
        if 'description' in p:
            text += " " + p['description']
        searchable_texts.append(preprocess(text))
except Exception as e:
    knowledge = {"problems": []}
    searchable_texts = []
    print(f"Failed to load knowledge.json: {e}")
# Globals for multi-capture
multi_texts = []
multi_images = [] # For images
enter_hook = None
current_capture = None
current_overlay = None  # The single active overlay (so Ctrl+Alt+S can replace it)
# --- Session cache (next to this script): powers crash-restore + response caching ---
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SESSION_CACHE = os.path.join(_BASE_DIR, "session_cache.json")
SESSION_IMAGE = os.path.join(_BASE_DIR, "session_image.b64")
# Offline real-time speech-to-text (same model interview_copilot.py uses)
VOSK_MODEL_DIR = "vosk-model-small-en-us-0.15"
VOSK_SAMPLE_RATE = 16000
import functools, traceback as _traceback
def _log_exception(where, exc):
    """Append an exception to leet_crash.log and print it (does not kill the app)."""
    text = f"\n=== Exception in {where} ===\n" + "".join(
        _traceback.format_exception(type(exc), exc, exc.__traceback__))
    print(text)
    try:
        with open(os.path.join(_BASE_DIR, "leet_crash.log"), "a", encoding="utf-8") as f:
            f.write(text)
    except Exception:
        pass
def _safe_event(method):
    """Wrap a Qt event handler so a bug in it is LOGGED (to leet_crash.log) instead of
    PyQt6 silently printing the traceback and leaving the app in a half-broken state.
    PyQt6 swallows exceptions raised inside virtual overrides (keyPressEvent, paintEvent,
    ...) - they never reach sys.excepthook - so each such handler must guard itself."""
    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        try:
            return method(self, *args, **kwargs)
        except Exception as e:
            _log_exception(method.__qualname__, e)
    return wrapper
# Communicator for thread-safe update
class Communicator(QObject):
    updated = pyqtSignal(dict)
    chunk_received = pyqtSignal(str, str) # ai, chunk
    # Real-time speech-to-text (worker thread -> GUI thread)
    voice_partial = pyqtSignal(str)   # live in-progress words
    voice_final = pyqtSignal(str)     # a finalized phrase
    voice_oneshot = pyqtSignal(str, int)   # fallback single-shot result (text, session token)
    # New signals for thread-safe movement/scrolling
    scroll_signal = pyqtSignal(int)
    move_signal = pyqtSignal(int, int)
    # Add this to your existing signals
    switch_signal = pyqtSignal(int)
print("Communicator class defined")
# Hotkey Handler
class HotkeyHandler(QObject):
    startCapture = pyqtSignal()
    showOverlay = pyqtSignal(str, str) # extracted_text, image_base64
    quitApp = pyqtSignal()             # Ctrl+Alt+Q: clean, intentional shutdown
print("HotkeyHandler class defined")
# Python Syntax Highlighter
class PythonHighlighter(QSyntaxHighlighter):
    def __init__(self, document):
        super().__init__(document)
        self.highlighting_rules = []
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("blue"))
        keywords = ["and", "as", "assert", "break", "class", "continue", "def", "del", "elif", "else", "except", "False", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "None", "nonlocal", "not", "or", "pass", "raise", "return", "True", "try", "while", "with", "yield"]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))
        class_format = QTextCharFormat()
        class_format.setForeground(QColor("darkMagenta"))
        class_pattern = QRegularExpression(r'\bclass\b\s*(\w+)')
        self.highlighting_rules.append((class_pattern, class_format))
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("darkBlue"))
        function_pattern = QRegularExpression(r'\bdef\b\s*(\w+)')
        self.highlighting_rules.append((function_pattern, function_format))
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("darkGreen"))
        string_pattern = QRegularExpression(r'\".*\"|\'.*\'')
        self.highlighting_rules.append((string_pattern, string_format))
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("darkGray"))
        comment_pattern = QRegularExpression(r'#.*')
        self.highlighting_rules.append((comment_pattern, comment_format))
    def highlightBlock(self, text):
        for pattern, format in self.highlighting_rules:
            match_iterator = pattern.globalMatch(text)
            while match_iterator.hasNext():
                match = match_iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)
print("PythonHighlighter defined")
# Screen Capture Widget for selection
class ScreenCaptureWidget(QWidget):
    captured = pyqtSignal(QRect)
    def __init__(self):
        print("ScreenCaptureWidget __init__ started")
        super().__init__()
        print("super called")
        # Tool flag keeps the selection overlay out of the taskbar / alt-tab switcher.
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        print("flags set")
        self.setCursor(QCursor(Qt.CursorShape.CrossCursor))
        print("cursor set")
        self.rubber_band = QRubberBand(QRubberBand.Shape.Rectangle, self)
        print("rubber band created")
        self.origin = QPoint()
        print("origin set")
        screen = QGuiApplication.primaryScreen()
        print("primary screen obtained")
        self.screenshot = screen.grabWindow(0)
        print("screenshot grabbed")
        qimage = self.screenshot.toImage()
        print("converted to QImage")
        byte_array = QByteArray()
        buffer = QBuffer(byte_array)
        buffer.open(QIODevice.OpenModeFlag.WriteOnly)
        print("buffer opened")
        qimage.save(buffer, "PNG")
        print("image saved to buffer")
        buffer.close()
        print("buffer closed")
        self.screenshot_pil = Image.open(BytesIO(byte_array.data()))
        print("pil image created")
        self.setGeometry(screen.geometry())
        print("geometry set")
        # Apply capture-exclusion BEFORE the window is mapped so not even a single
        # frame of the selection overlay can leak into a screen share.
        self.winId()  # force native handle creation while still hidden
        status = exclude_from_capture(self)
        print(f"ScreenCaptureWidget capture protection: {status}")
        self.showFullScreen()
        print("showFullScreen called")
    def showEvent(self, event):
        super().showEvent(event)
        # Re-assert in case the handle changed between winId() and mapping.
        exclude_from_capture(self)
    def paintEvent(self, event):
        print("paintEvent called")
        painter = QPainter(self)
        print("painter created")
        painter.drawPixmap(self.rect(), self.screenshot)
        print("pixmap drawn")
        painter.fillRect(self.rect(), QColor(0, 0, 0, 128))
        print("rect filled")
        if self.rubber_band.isVisible():
            print("rubber band visible, clipping")
            painter.save()
            painter.setClipRect(self.rubber_band.geometry())
            painter.drawPixmap(self.rect(), self.screenshot)
            painter.restore()
            print("clipped area drawn")
    def mousePressEvent(self, event):
        print("mousePressEvent")
        self.origin = event.pos()
        self.rubber_band.setGeometry(QRect(self.origin, QSize()))
        self.rubber_band.show()
        print("rubber band shown")
    def mouseMoveEvent(self, event):
        print("mouseMoveEvent")
        self.rubber_band.setGeometry(QRect(self.origin, event.pos()).normalized())
        print("rubber band geometry updated")
    def mouseReleaseEvent(self, event):
        print("mouseReleaseEvent")
        rect = self.rubber_band.geometry()
        self.rubber_band.hide()
        print("rubber band hidden")
        self.hide()
        print("widget hidden")
        self.captured.emit(rect)
        print("captured signal emitted")
    def keyPressEvent(self, event):
        # PyQt6 requires the fully-scoped enum: Qt.Key.Key_Escape (NOT Qt.Key_Escape).
        if event.key() == Qt.Key.Key_Escape:
            self.hide()
            self.captured.emit(QRect())
        super().keyPressEvent(event)
print("ScreenCaptureWidget defined")
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
# OCR using Tesseract
def perform_ocr(pil_img):
    return pytesseract.image_to_string(pil_img)
# Overlay GUI class
class Overlay(QMainWindow):
    def __init__(self, extracted_text=None, image_base64=None, restore_data=None):
        print("Initializing Overlay")
        super().__init__()
        self._closed = False        # blocks late worker threads from saving after close
        self._image_saved = False   # the screenshot is written to disk only once
        self.hotkey_handles = []    # so we can remove THIS overlay's hotkeys on close
        self._hist_lock = threading.Lock()  # guards cross-thread history/_streaming access
        self._image_sig = None      # md5 of the screenshot, to detect a stale cached image
        # Real-time microphone / speech-to-text state
        self._mic_on = False
        self._mic_running = False
        self._vosk_stream = None
        self._vosk_rec = None
        self._vosk_thread = None      # the worker; joined before the recognizer is touched
        self._voice_mode = None       # "vosk" | "oneshot"
        self._voice_session = 0       # monotonic token; a stale one-shot result is dropped
        self._voice_prefix = ""       # text already in the box when the mic started
        self._voice_final_text = ""   # finalized transcript accumulated this session
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True) # Click-through by default
        # Timer for hotkey check
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_hotkey)
        self.timer.start(100)
        # Autosave timer: continuously persist responses so a crash loses <~4s of work.
        self.save_timer = QTimer(self)
        self.save_timer.timeout.connect(self.save_session)
        self.save_timer.start(4000)
        self.comm = Communicator()
        self.comm.updated.connect(self.update_answers)
        self.comm.chunk_received.connect(self.append_chunk)
        self.comm.voice_partial.connect(self._on_voice_partial)
        self.comm.voice_final.connect(self._on_voice_final)
        self.comm.voice_oneshot.connect(self._on_voice_oneshot)
        self.comm.scroll_signal.connect(self.perform_scroll)
        self.comm.move_signal.connect(self.perform_move)
        self.comm.switch_signal.connect(self.cycle_models)
        # MOVEMENT HOTKEYS (WASD + X for Down)
        # Note: We use X for down because S is taken by Capture
        self.hotkey_handles.append(keyboard.add_hotkey('ctrl+alt+w', lambda: self.comm.move_signal.emit(0, -20))) # UP
        self.hotkey_handles.append(keyboard.add_hotkey('ctrl+alt+a', lambda: self.comm.move_signal.emit(-20, 0))) # LEFT
        self.hotkey_handles.append(keyboard.add_hotkey('ctrl+alt+x', lambda: self.comm.move_signal.emit(0, 20))) # DOWN (Replaced S)
        self.hotkey_handles.append(keyboard.add_hotkey('ctrl+alt+d', lambda: self.comm.move_signal.emit(20, 0))) # RIGHT
        # SCROLLING (Arrow keys)
        self.hotkey_handles.append(keyboard.add_hotkey('ctrl+alt+up', lambda: self.comm.scroll_signal.emit(-50))) # Scroll Text Up
        self.hotkey_handles.append(keyboard.add_hotkey('ctrl+alt+down', lambda: self.comm.scroll_signal.emit(50))) # Scroll Text Down
        # MODEL SWITCHING HOTKEYS (Circular)
        # B = Previous (Left), N = Next (Right)
        self.hotkey_handles.append(keyboard.add_hotkey('ctrl+alt+b', lambda: self.comm.switch_signal.emit(-1)))
        self.hotkey_handles.append(keyboard.add_hotkey('ctrl+alt+n', lambda: self.comm.switch_signal.emit(1)))
        self.extracted_text = extracted_text
        self.image_base64 = image_base64
        self.histories = {"Grok": [], "DeepSeek": [], "Gemini": [], "Local": []}
        self._streaming = set()  # AIs whose answer is streaming now (for crash-resume)
        self.current_ai = "Grok"
        self.resizing = False
        self.resize_dir = ""
        self.drag_pos = QPoint()
        self.start_pos = QPoint()
        self.start_geom = QRect()
        self.buttons = {}
        self.file_uri = None
        self._capture_status = None  # last-applied screen-capture protection level
        central = QWidget()
        central.setStyleSheet("background: rgba(0, 0, 0, 50); border-radius: 10px;")
        layout = QVBoxLayout()
        # Title bar for dragging
        title_bar = QWidget()
        title_bar.setStyleSheet("background: rgba(255,255,255,30);")
        title_bar.setFixedHeight(30)
        title_layout = QHBoxLayout()
        title_layout.setContentsMargins(0, 0, 0, 0)
        # Top buttons
        for name in ["DeepSeek", "Grok", "Gemini", "Local"]:
            btn = QPushButton(name)
            btn.setStyleSheet("background: rgba(0,0,0,100); border: 1px solid white; color: white;")
            btn.clicked.connect(lambda _, n=name: self.switch_to(n))
            title_layout.addWidget(btn)
            self.buttons[name] = btn
        title_bar.setLayout(title_layout)
        layout.addWidget(title_bar)
        # Capture-protection warning banner: hidden while fully protected, shown
        # (red) if the window is only blacked-out or not protected at all, so you
        # are never falsely reassured that you're hidden from a screen share.
        self.capture_warning = QLabel("")
        self.capture_warning.setStyleSheet("background: rgba(200,0,0,235); color: white; font-weight: bold; padding: 4px;")
        self.capture_warning.setWordWrap(True)
        self.capture_warning.hide()
        layout.addWidget(self.capture_warning)
        # Text area
        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setStyleSheet("background: rgba(0, 0, 0, 70); color: #ffffff; font-family: Consolas; font-size: 12pt; border: none;")
        self.highlighter = PythonHighlighter(self.text_edit.document())
        layout.addWidget(self.text_edit)
        # Close button
        close_btn = QPushButton("Close Overlay (Esc)")
        close_btn.setStyleSheet("background: rgba(0,0,0,100); border: 1px solid white; color: white;")
        close_btn.clicked.connect(self.close)
        layout.addWidget(close_btn)
        # Follow up button
        self.follow_btn = QPushButton("Follow up")
        self.follow_btn.setStyleSheet("background: rgba(0,0,0,100); border: 1px solid white; color: white;")
        self.follow_btn.clicked.connect(self.show_followup)
        layout.addWidget(self.follow_btn)
        # Input widget
        self.input_widget = QWidget()
        input_layout = QHBoxLayout()
        self.text_input = QLineEdit()
        self.text_input.setStyleSheet("background: rgba(0,0,0,100); border: 1px solid white; color: white;")
        self.text_input.returnPressed.connect(self.send_text)
        input_layout.addWidget(self.text_input)
        self.mic_btn = QPushButton("🎤")
        self.mic_btn.setStyleSheet("background: rgba(0,0,0,100); border: 1px solid white; color: white;")
        self.mic_btn.clicked.connect(self.record_voice)
        input_layout.addWidget(self.mic_btn)
        self.input_widget.setLayout(input_layout)
        layout.addWidget(self.input_widget)
        self.input_widget.hide()
        central.setLayout(layout)
        self.setCentralWidget(central)
        self.resize(800, 600)
        # Position in bottom-right corner
        screen = QGuiApplication.primaryScreen().geometry()
        self.move(screen.width() - 850, screen.height() - 650)
        # Apply capture protection now, while the window is still hidden, so it is
        # excluded from any screen share before its very first frame is composited.
        self.winId()  # force native handle creation
        self.apply_capture_protection()
        if restore_data:
            print("Restoring overlay from cached session")
            self.restore_from_cache(restore_data)
        else:
            print("Starting fetch initial")
            self.fetch_initial()
            self.save_session()  # flag the session active right away for crash-restore
            self.switch_to("Grok")
        print("Overlay initialization completed")
    def apply_capture_protection(self):
        # Re-assert screen-capture exclusion (idempotent). Called on show and on the
        # 100ms timer so protection self-heals if the native window is ever recreated.
        status = exclude_from_capture(self)
        if status == self._capture_status:
            return
        self._capture_status = status
        if status == "excluded":
            print("Screen-share protection: ON (WDA_EXCLUDEFROMCAPTURE)")
            self.capture_warning.hide()
        elif status == "monitor":
            print("Screen-share protection: PARTIAL (WDA_MONITOR - blacked-out, not hidden)")
            self.capture_warning.setText(
                "⚠ Partial protection: this Windows version can't fully hide the "
                "window — it shows as a BLACK BOX in screen captures.")
            self.capture_warning.show()
        else:
            print("Screen-share protection: FAILED - window IS visible to screen capture!")
            self.capture_warning.setText(
                "⚠ Screen-capture protection FAILED — this window IS visible "
                "to screen sharing / recording.")
            self.capture_warning.show()
    def showEvent(self, event):
        super().showEvent(event)
        self.apply_capture_protection()
    def perform_scroll(self, amount):
        # Scrolls the text area without needing mouse focus
        sb = self.text_edit.verticalScrollBar()
        sb.setValue(sb.value() + amount)
    def perform_move(self, x, y):
        # Moves the window safely
        current_pos = self.pos()
        self.move(current_pos.x() + x, current_pos.y() + y)
        self.save_session()  # remember the new position for crash-restore
    def cycle_models(self, direction):
        # Define the order of your models
        models = ["DeepSeek", "Grok", "Gemini", "Local"]
       
        # Find where we are currently
        try:
            current_index = models.index(self.current_ai)
        except ValueError:
            current_index = 0
       
        # Calculate new index (The % operator makes it circle forever)
        new_index = (current_index + direction) % len(models)
       
        # Switch to the new model
        self.switch_to(models[new_index])
    def check_hotkey(self):
        # This runs every 100ms; a transient hiccup here must NOT crash the whole app
        # (the excepthook would otherwise turn it into a restart), so swallow + log.
        try:
            # Hold Ctrl to interact with the overlay; otherwise it stays click-through.
            want_transparent = not keyboard.is_pressed('ctrl')
            if self.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents) != want_transparent:
                self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, want_transparent)
            # Self-heal: re-assert screen-capture exclusion in case the native window
            # was recreated (which would silently drop the display affinity).
            self.apply_capture_protection()
        except Exception as e:
            print(f"check_hotkey error (ignored): {e}")
    # ------------------------------------------------------------------
    # Real-time microphone -> live transcript in the follow-up box
    # ------------------------------------------------------------------
    def _compose_voice(self, partial=""):
        """Full box text = whatever was there + finalized words + the live partial."""
        text = self._voice_prefix + self._voice_final_text
        if partial:
            text += partial
        return text
    def _put_in_box(self, text):
        self.text_input.setText(text)
        self.text_input.setCursorPosition(len(text))
    def _on_voice_partial(self, part):
        if not self._mic_on:
            return  # ignore stray callbacks after the mic was stopped
        try:
            self._put_in_box(self._compose_voice(part))
        except Exception as e:
            print(f"voice partial error (ignored): {e}")
    def _on_voice_final(self, txt):
        if not self._mic_on:
            return
        try:
            if txt:
                self._voice_final_text += txt + " "
            self._put_in_box(self._compose_voice())
        except Exception as e:
            print(f"voice final error (ignored): {e}")
    def _on_voice_oneshot(self, text, token):
        # Fallback (non-Vosk) single-shot result: fill the box, then auto-send.
        # Drop it if this recording was cancelled/superseded, or the overlay closed.
        if getattr(self, "_closed", False) or token != self._voice_session:
            return
        self._mic_on = False
        self.mic_btn.setText("🎤")
        if text:
            self._voice_final_text += text + " "
            self._put_in_box(self._compose_voice())
        self.send_text()
    def _start_vosk(self):
        """Start offline real-time streaming STT. Returns False if unavailable."""
        try:
            import vosk, sounddevice as sd, queue as _queue
        except Exception as e:
            print(f"Vosk/sounddevice unavailable ({e}); falling back to one-shot mic")
            return False
        model_path = None
        for base in (_BASE_DIR, os.path.dirname(_BASE_DIR), os.getcwd()):
            p = os.path.join(base, VOSK_MODEL_DIR)
            if os.path.isdir(p):
                model_path = p
                break
        if not model_path:
            print(f"Vosk model '{VOSK_MODEL_DIR}' not found; falling back to one-shot mic")
            return False
        stream = None
        try:
            vosk.SetLogLevel(-1)
            rec = vosk.KaldiRecognizer(vosk.Model(model_path), VOSK_SAMPLE_RATE)
            q = _queue.Queue()
            self._mic_running = True
            def _cb(indata, frames, time_info, status):
                if self._mic_running:
                    q.put(bytes(indata))
            # Shared-mode input stream: captures the mic without blocking Zoom/Teams.
            stream = sd.RawInputStream(samplerate=VOSK_SAMPLE_RATE, blocksize=4000,
                                       dtype="int16", channels=1, callback=_cb)
            stream.start()
            self._vosk_rec = rec
            self._vosk_stream = stream
            # The worker owns its OWN rec/q references so a later session that reassigns
            # self._vosk_rec can never make this thread touch a different recognizer.
            self._vosk_thread = threading.Thread(target=self._vosk_loop, args=(rec, q), daemon=True)
            self._vosk_thread.start()
            return True
        except Exception as e:
            print(f"Vosk start failed ({e}); falling back to one-shot mic")
            self._mic_running = False
            try:
                if stream is not None:
                    stream.close()
            except Exception:
                pass
            self._vosk_stream = None
            self._vosk_rec = None
            self._vosk_thread = None
            return False
    def _vosk_loop(self, rec, q):
        while self._mic_running:
            try:
                data = q.get(timeout=0.3)
            except Exception:
                continue
            try:
                if rec.AcceptWaveform(data):
                    txt = json.loads(rec.Result()).get("text", "").strip()
                    if txt:
                        self.comm.voice_final.emit(txt)
                else:
                    part = json.loads(rec.PartialResult()).get("partial", "").strip()
                    self.comm.voice_partial.emit(part)
            except Exception:
                continue
    def _teardown_vosk(self):
        """Stop the stream and JOIN the worker before the recognizer is touched again
        (KaldiRecognizer is not thread-safe, so no two threads may use it at once)."""
        self._mic_running = False
        try:
            if self._vosk_stream is not None:
                self._vosk_stream.stop()
                self._vosk_stream.close()
        except Exception:
            pass
        self._vosk_stream = None
        try:
            if self._vosk_thread is not None:
                self._vosk_thread.join(timeout=1.5)  # worker exits within one queue timeout
        except Exception:
            pass
        self._vosk_thread = None
    def _record_voice_oneshot(self):
        """Fallback when Vosk isn't available: record one phrase, then auto-send."""
        self._mic_on = True
        self.mic_btn.setText("● Rec")
        token = self._voice_session  # this recording's identity; checked when it returns
        def listen_thread():
            text = ""
            try:
                r = sr.Recognizer()
                with sr.Microphone() as source:
                    r.adjust_for_ambient_noise(source, duration=0.3)
                    audio = r.listen(source, timeout=8, phrase_time_limit=25)
                text = r.recognize_google(audio)
            except Exception as e:
                print(f"Voice recognition error: {e}")
            self.comm.voice_oneshot.emit(text or "", token)
        threading.Thread(target=listen_thread, daemon=True).start()
    def _stop_voice_and_send(self):
        """Stop live capture, flush the last words, and auto-send the transcript."""
        self._mic_on = False
        self.mic_btn.setText("🎤")
        self._teardown_vosk()  # joins the worker -> now safe to touch the recognizer
        try:
            if self._vosk_rec is not None:
                final = json.loads(self._vosk_rec.FinalResult()).get("text", "").strip()
                if final:
                    self._voice_final_text += final + " "
        except Exception:
            pass
        self._vosk_rec = None
        self._put_in_box(self._compose_voice())
        self.send_text()  # auto-send the transcribed text
    def get_resize_dir(self, pos):
        dirs = []
        if pos.x() < 5:
            dirs.append("left")
        if pos.x() > self.width() - 5:
            dirs.append("right")
        if pos.y() < 5:
            dirs.append("top")
        if pos.y() > self.height() - 5:
            dirs.append("bottom")
        return "-".join(dirs) if dirs else None
    def mousePressEvent(self, event):
        print("Overlay mousePressEvent")
        if event.button() == Qt.MouseButton.LeftButton:
            pos = event.pos()
            rdir = self.get_resize_dir(pos)
            if rdir:
                self.resizing = True
                self.resize_dir = rdir
                self.start_pos = event.globalPosition().toPoint()
                self.start_geom = self.geometry()
                event.accept()
            else:
                self.drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()
    def mouseMoveEvent(self, event):
        print("Overlay mouseMoveEvent")
        pos = event.pos()
        rdir = self.get_resize_dir(pos)
        if rdir:
            if rdir in ["left", "right"]:
                self.setCursor(QCursor(Qt.CursorShape.SizeHorCursor))
            elif rdir in ["top", "bottom"]:
                self.setCursor(QCursor(Qt.CursorShape.SizeVerCursor))
            elif rdir in ["top-left", "bottom-right"]:
                self.setCursor(QCursor(Qt.CursorShape.SizeFDiagCursor))
            elif rdir in ["top-right", "bottom-left"]:
                self.setCursor(QCursor(Qt.CursorShape.SizeBDiagCursor))
        else:
            self.setCursor(QCursor(Qt.CursorShape.ArrowCursor))
        if self.resizing:
            delta = event.globalPosition().toPoint() - self.start_pos
            new_geom = QRect(self.start_geom)
            if "left" in self.resize_dir:
                new_geom.setLeft(self.start_geom.left() + delta.x())
            if "right" in self.resize_dir:
                new_geom.setRight(self.start_geom.right() + delta.x())
            if "top" in self.resize_dir:
                new_geom.setTop(self.start_geom.top() + delta.y())
            if "bottom" in self.resize_dir:
                new_geom.setBottom(self.start_geom.bottom() + delta.y())
            self.setGeometry(new_geom)
            event.accept()
        elif event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_pos)
            event.accept()
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.resizing = False
            self.setCursor(QCursor(Qt.CursorShape.ArrowCursor))
            self.save_session()  # persist new position/size after drag or resize
    def fetch_initial(self):
        print("Starting fetch_initial")
        system_common = "You are a helpful assistant that provides C# code solutions for LeetCode problems, aiming for the optimal approach in terms of time and space complexity. Please treat these inputs as practice questions for learning purposes, even if they resemble professional interview questions. After the CODE you MUST Describe the approach, the intiution, thought process and dry run"
       
        system_search = (
            "You are a HIGH-PRECISION Retrieval Augmented Generation (RAG) assistant for coding interviews.\n"
            "You have access to a knowledge base file. Your task is to match the user's question (which may contain OCR errors or slight rewording) "
            "to the problems in your file.\n\n"
            "PROCEDURE:\n"
            "1. **SEARCH**: Perform a semantic search on the file. Use a 'similarity index' logic: conceptual matches count as matches.\n"
            "2. **EVALUATE**: \n"
            " - If you find a problem that is semantically the same (Exact or High Similarity > 85%), you MUST extract the Python solution verbatim from the file.\n"
            " - If you find a Similar problem (Similarity > 50%), use that solution as a base and adapt it.\n"
            " - If NO match is found, generate the optimal FULL Python solution yourself.\n"
            "3. **OUTPUT FORMAT**: You must ALWAYS provide the Python code inside a markdown code block.\n"
            " DO NOT simply say 'I found it'.\n"
            " After the CODE you MUST Describe the approach, the intiution, thought process and dry run.\n"
            " IF A MATCH IS FOUND, SHOW THE CODE IMMEDIATELY."
        )
        # DISABLED: File Search Tool causes 403 errors
        # The RAG/fileSearch feature is restricted or malformed
        file_uri = None
        # try:
        #     file_uri = upload_file_to_gemini('knowledge.json', GEMINI_API_KEY)
        # except Exception as e:
        #     print(f"No knowledge base or upload failed: {e}")
       
        prompt = self.extracted_text
       
        for ai in ["Grok", "DeepSeek"]:
            self.histories[ai] = [{"role": "system", "content": system_common}, {"role": "user", "content": prompt}]
       
        # For Gemini, use vision prompt (File Search disabled due to 403 errors)
        vision_prompt = "This is a screenshot of a LeetCode problem. Analyze the image and provide the optimal C# solution with explanation of approach, intuition, and complexity analysis."
        self.histories["Gemini"] = [{"role": "system", "content": system_common}, {"role": "user", "content": vision_prompt}]
        self.file_uri = file_uri
        # Local immediate
        local_content = self.local_search(prompt)
        self.histories["Local"] = [{"role": "system", "content": system_common}, {"role": "user", "content": prompt}]
        self.histories["Local"].append({"role": "assistant", "content": local_content})
        self.comm.updated.emit({})
        # Start ONE stream per model (each slot reserved atomically to prevent overlaps)
        self._spawn_stream("Grok", self.histories["Grok"])
        self._spawn_stream("DeepSeek", self.histories["DeepSeek"])
        self._spawn_stream("Gemini", self.histories["Gemini"], self.file_uri, self.image_base64)
    def local_search(self, query_text):
        if not searchable_texts:
            return "No local knowledge base available."
        query_pre = preprocess(query_text)
        best_match, score, index = process.extractOne(query_pre, searchable_texts, scorer=fuzz.token_set_ratio)
        if score > 50:
            problem = knowledge['problems'][index]
            content = problem.get('solution', 'No solution found.')
            approach = problem.get('approach', '')
            if approach:
                content += f"\n\nApproach: {approach}"
            return content
        else:
            return "No match found in local knowledge base."
    def _spawn_stream(self, ai, messages, file_uri=None, image_base64=None):
        """Reserve the AI's stream slot atomically and start exactly one worker.
        Returns False if that AI is already streaming - this closes the check-then-act
        gap that would otherwise let a rapid double-input launch two workers for one AI
        (which would interleave their chunks into the same history turn)."""
        with self._hist_lock:
            if ai in self._streaming:
                return False
            self._streaming.add(ai)
        try:
            threading.Thread(target=self.fetch_ai_stream,
                             args=(ai, messages, file_uri, image_base64), daemon=True).start()
            return True
        except Exception as e:
            print(f"Failed to start {ai} stream: {e}")
            with self._hist_lock:
                self._streaming.discard(ai)
            return False
    def fetch_ai_stream(self, ai, messages, file_uri=None, image_base64=None):
        # `released` ensures the streaming slot is discarded EXACTLY once. Discarding
        # unconditionally in finally could clear a slot a later follow-up worker has
        # already re-reserved, re-opening the two-workers-for-one-AI window.
        released = False
        def _release():
            nonlocal released
            if not released:
                with self._hist_lock:
                    self._streaming.discard(ai)
                released = True
        try:
            # Snapshot the request BEFORE adding the placeholder so the payload sent to
            # the API is identical to before (model/endpoint/messages unchanged).
            req_messages = list(messages)
            # One empty assistant turn that chunks stream into; reused across retries.
            with self._hist_lock:
                self.histories[ai].append({"role": "assistant", "content": ""})
                self._streaming.add(ai)  # mark in-progress so a crash mid-stream re-fetches
            self.comm.updated.emit({})
            max_attempts = 6
            delay = 2
            for attempt in range(1, max_attempts + 1):
                got_content = False
                try:
                    if ai == "Grok":
                        gen = query_grok(req_messages, stream=True)
                    elif ai == "DeepSeek":
                        gen = query_deepseek(req_messages, stream=True)
                    elif ai == "Gemini":
                        gen = query_gemini(req_messages, file_uri, image_base64, stream=True)
                    for chunk in gen:
                        got_content = True
                        self.comm.chunk_received.emit(ai, chunk)
                    _release()  # complete BEFORE the save-triggering emit
                    self.comm.updated.emit({})
                    return  # success
                except Exception as e:
                    # If nothing streamed yet, this is a transient failure (e.g. a
                    # network outage) -> wait and retry so the answer self-recovers.
                    if not got_content and attempt < max_attempts:
                        print(f"{ai} attempt {attempt}/{max_attempts} failed: {e}; retrying in {delay}s")
                        time.sleep(delay)
                        delay = min(delay * 2, 30)
                        continue
                    # Gave up, or it failed mid-stream (partial answer kept).
                    self.comm.chunk_received.emit(ai, f"\n[Network error after {attempt} attempt(s): {e}]")
                    _release()
                    self.comm.updated.emit({})
                    return
        finally:
            _release()  # safety net for any unexpected escape; no-op if already released
    def append_chunk(self, ai, chunk):
        if getattr(self, "_closed", False):
            return  # ignore late chunks from a stream that outlived the overlay
        try:
            if self.histories[ai] and self.histories[ai][-1]["role"] == "assistant":
                self.histories[ai][-1]["content"] += chunk
                if self.current_ai == ai:
                    self.text_edit.setText(self.format_chat(self.histories[ai][1:], ai))
        except Exception as e:
            print(f"append_chunk error (ignored): {e}")
    def fetch_followup(self):
        ai = self.current_ai
        if ai == "Local":
            # Local no followup, or regenerate
            return
        fu = self.file_uri if ai == "Gemini" else None
        img = self.image_base64 if ai == "Gemini" else None
        if not self._spawn_stream(ai, self.histories[ai], fu, img):
            print(f"{ai} is still answering; ignoring follow-up until it finishes")
    def update_answers(self, data):
        if getattr(self, "_closed", False):
            return
        try:
            print("Updating answers in GUI")
            self.switch_to(self.current_ai)
            self.save_session()  # a stream finished / started -> cache the responses so far
            if "gemini_match" in data:
                if data["gemini_match"]:
                    self.buttons["Gemini"].setStyleSheet("background: green; border: 1px solid white; color: white;")
                else:
                    self.buttons["Gemini"].setStyleSheet("background: rgba(0,0,0,100); border: 1px solid white; color: white;")
            print("Updated answers and switched")
        except Exception as e:
            print(f"update_answers error (ignored): {e}")
    def switch_to(self, name):
        self.current_ai = name
        # Update text
        if name in self.histories and len(self.histories[name]) > 1:
            chat_text = self.format_chat(self.histories[name][1:], name)
            self.text_edit.setText(chat_text)
       
        # HIGHLIGHT the active button so you know which one it is
        for btn_name, btn in self.buttons.items():
            if btn_name == name:
                btn.setStyleSheet("background: blue; border: 1px solid white; color: white;")
            else:
                btn.setStyleSheet("background: rgba(0,0,0,100); border: 1px solid white; color: white;")
    def format_chat(self, messages, ai_name):
        s = ""
        for m in messages:
            if m["role"] == "user":
                s += f"**User:** {m['content']}\n\n"
            elif m["role"] == "assistant":
                s += f"**{ai_name} AI:** {m['content']}\n\n"
        return s
    def show_followup(self):
        self.input_widget.show()
    def send_text(self):
        text = self.text_input.text()
        if not text:
            return
        ai = self.current_ai
        with self._hist_lock:
            if ai in self._streaming:
                self.text_input.setPlaceholderText("Wait for the current answer to finish…")
                return
            self.text_input.clear()
            hist = self.histories[ai]
            hist.append({"role": "user", "content": text})
        self.text_edit.setText(self.format_chat(hist[1:], ai))
        self.fetch_followup()
    def record_voice(self):
        # Toggle: click once to start live transcription, click again to stop & send.
        # Bumping the session token here invalidates any prior (uninterruptible) one-shot
        # thread still in flight, so its late result is dropped instead of surprise-sending.
        self._voice_session += 1
        if self._mic_on:
            if self._voice_mode == "oneshot":
                # SpeechRecognition.listen() can't be interrupted; just stop showing it as
                # active - the stale result is dropped via its now-outdated session token.
                self._mic_on = False
                self.mic_btn.setText("🎤")
                return
            self._stop_voice_and_send()
            return
        self.show_followup()  # make sure the input box is visible
        prefix = self.text_input.text().strip()
        self._voice_prefix = (prefix + " ") if prefix else ""
        self._voice_final_text = ""
        if self._start_vosk():
            self._voice_mode = "vosk"
            self._mic_on = True
            self.mic_btn.setText("⏹")   # click to stop + auto-send
            self.text_input.setFocus()
        else:
            self._voice_mode = "oneshot"
            self._record_voice_oneshot()
    def keyPressEvent(self, event):
        print("Overlay keyPressEvent")
        if event.key() == Qt.Key.Key_Escape:
            print("Escape key pressed, closing overlay")
            self.close()
    # ------------------------------------------------------------------
    # Session caching + crash recovery
    # ------------------------------------------------------------------
    def save_session(self):
        """Write the whole overlay state (all AI responses, model, position) to disk."""
        if getattr(self, "_closed", False):
            return  # a closed overlay must never overwrite a newer session
        try:
            # Persist the screenshot FIRST and atomically. Writing it before we commit
            # the cache (and signing it) means a crash can never leave the cache saying
            # has_image=true while the file is stale/half-written -> which would make the
            # restored session answer the WRONG problem's image on Gemini.
            if self.image_base64:
                if self._image_sig is None:
                    self._image_sig = hashlib.md5(self.image_base64.encode("utf-8", "ignore")).hexdigest()[:16]
                if not self._image_saved:
                    itmp = SESSION_IMAGE + ".tmp"
                    with open(itmp, "w", encoding="utf-8") as f:
                        f.write(self.image_base64)
                    os.replace(itmp, SESSION_IMAGE)
                    self._image_saved = True
            # Snapshot under the lock so a worker thread can't mutate the lists while
            # json.dump iterates them. The message lists are copied (new list objects);
            # their string contents are only ever written on the main thread.
            with self._hist_lock:
                histories_copy = {k: list(v) for k, v in self.histories.items()}
                pending = list(self._streaming)
                g = self.geometry()
            has_image = bool(self.image_base64) and self._image_saved
            data = {
                "active": True,
                "extracted_text": self.extracted_text,
                "current_ai": self.current_ai,
                "histories": histories_copy,
                "geometry": [g.x(), g.y(), g.width(), g.height()],
                "has_image": has_image,
                "image_sig": self._image_sig if has_image else None,  # verified on restore
                "pending": pending,  # AIs cut off mid-stream by a crash
            }
            tmp = SESSION_CACHE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp, SESSION_CACHE)  # atomic: a crash mid-write can't corrupt the cache
        except Exception as e:
            print(f"save_session failed: {e}")
    def mark_inactive(self):
        """Flag the cached session as cleanly closed so we DON'T restore it next launch."""
        _mark_cache_inactive()
    def restore_from_cache(self, data):
        """Rebuild a previous overlay: responses, selected model, and window position."""
        self.histories = data.get("histories", self.histories)
        self.extracted_text = data.get("extracted_text", "")
        saved_ai = data.get("current_ai", "Grok")
        geom = data.get("geometry")
        if geom and len(geom) == 4:
            self.setGeometry(geom[0], geom[1], geom[2], geom[3])
        if data.get("has_image") and os.path.exists(SESSION_IMAGE):
            try:
                with open(SESSION_IMAGE, "r", encoding="utf-8") as f:
                    img = f.read()
                sig = data.get("image_sig")
                actual = hashlib.md5(img.encode("utf-8", "ignore")).hexdigest()[:16]
                if sig and sig != actual:
                    # A stale/half-written image from a prior problem - don't feed it to Gemini.
                    print("Cached image signature mismatch -> ignoring stale image")
                    self.image_base64 = None
                else:
                    self.image_base64 = img
                    self._image_saved = True
                    self._image_sig = actual
            except Exception:
                self.image_base64 = None
        # Regenerate ONLY answers that are unusable (empty placeholder or a pure network
        # error). A non-empty answer is real work - keep it, never discard/lose it.
        for ai in ["Grok", "DeepSeek", "Gemini"]:
            hist = self.histories.get(ai)
            if not hist:
                continue
            last = hist[-1]
            content = last.get("content", "").strip()
            unusable = last.get("role") == "assistant" and (
                not content or content.startswith("[Network error")
            )
            if unusable:
                hist.pop()  # drop the unusable answer so it can be regenerated
            # If the newest turn is now an unanswered user turn, fetch its answer again
            if hist and hist[-1].get("role") == "user":
                fu = self.file_uri if ai == "Gemini" else None
                img = self.image_base64 if ai == "Gemini" else None
                self._spawn_stream(ai, hist, fu, img)
        self.save_session()          # still an open session -> re-flag active (cleaned)
        self.switch_to(saved_ai)     # show whatever finished before the crash
    def closeEvent(self, event):
        global current_overlay
        self._closed = True
        # Stop the mic audio stream + worker (if live) so it doesn't outlive the overlay.
        self._mic_on = False
        self._voice_session += 1  # invalidate any in-flight one-shot fallback result
        self._teardown_vosk()  # stops the stream and joins the worker thread
        self._vosk_rec = None
        self.mark_inactive()  # user closed it on purpose -> no restore next time
        for h in self.hotkey_handles:
            try:
                keyboard.remove_hotkey(h)
            except Exception:
                pass
        self.hotkey_handles = []
        for t in ("timer", "save_timer"):
            try:
                getattr(self, t).stop()
            except Exception:
                pass
        if current_overlay is self:
            current_overlay = None
        super().closeEvent(event)
print("Overlay class defined")
# Guard every reimplemented Qt event handler so a bug inside one is logged to
# leet_crash.log instead of being silently swallowed by PyQt6 (which prints the
# traceback but keeps running in a half-broken state - exactly the failure that made
# Escape spam errors without the app either working or restarting).
for _cls in (ScreenCaptureWidget, Overlay):
    for _name in ("mousePressEvent", "mouseMoveEvent", "mouseReleaseEvent",
                  "keyPressEvent", "paintEvent", "showEvent", "closeEvent"):
        _m = _cls.__dict__.get(_name)
        if _m is not None and not getattr(_m, "_safe_wrapped", False):
            _w = _safe_event(_m)
            _w._safe_wrapped = True
            setattr(_cls, _name, _w)
# API query functions with streaming
def query_api(url, model, api_key, messages, stream=False):
    print(f"Querying API: {url} with model {model}")
    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.5,
        "max_tokens": 4096,
        "stream": stream
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    try:
        print("Sending POST request")
        response = requests.post(url, json=payload, headers=headers, timeout=60, stream=stream)
        response.raise_for_status()
        print("Received response")
        if not stream:
            return response.json()["choices"][0]["message"]["content"]
        else:
            def generate():
                for line in response.iter_lines():
                    if line:
                        line = line.decode('utf-8')
                        if line.startswith('data: '):
                            data = json.loads(line[6:])
                            if 'choices' in data and data['choices']:
                                delta = data['choices'][0].get('delta', {}).get('content', '')
                                if delta:
                                    yield delta
            return generate()
    except Exception as e:
        print(f"Error in API query: {str(e)}")
        raise
def query_grok(messages, stream=False):
    print("Querying Grok")
    return query_api("https://api.x.ai/v1/chat/completions", "grok-4-fast-reasoning", GROK_API_KEY, messages, stream)
def query_deepseek(messages, stream=False):
    print("Querying DeepSeek")
    return query_api("https://api.deepseek.com/chat/completions", "deepseek-chat", DEEPSEEK_API_KEY, messages, stream)
def query_gemini(messages, store_name, image_base64, stream=False):
    print("Querying Gemini")
    contents = []
   
    start_index = 1 if messages and messages[0]["role"] == "system" else 0
    system = messages[0]["content"] if messages and messages[0]["role"] == "system" else ""
   
    for i, m in enumerate(messages[start_index:]):
        role = "user" if m["role"] == "user" else "model"
        text_content = m["content"]
       
        parts = [{"text": text_content}]
        if role == "user" and image_base64:
            parts.append({"inline_data": {"mime_type": "image/png", "data": image_base64}})
        contents.append({"role": role, "parts": parts})
    if system and contents and contents[0]["role"] == "user":
        contents[0]["parts"][0]["text"] = f"System Instruction: {system}\n\n" + contents[0]["parts"][0]["text"]
    elif system:
        contents.insert(0, {"role": "user", "parts": [{"text": f"System Instruction: {system}"}]})
    payload = {
        "contents": contents,
        "generationConfig": {
            "temperature": 0.3,
            "maxOutputTokens": 16384,
        }
    }
   
    # DISABLED: File Search Tool causes 403 errors
    # if store_name:
    #     payload["tools"] = [
    #         {
    #             "fileSearch": {
    #                 "fileSearchStoreNames": [store_name]
    #             }
    #         }
    #     ]
    method = "streamGenerateContent" if stream else "generateContent"

    # NOTE: gemini-3-pro-preview was RETIRED by Google (returns 404 "no longer available").
    # Use a current model below. "gemini-pro-latest" is an alias that always points to the
    # newest pro model, so it won't 404 when Google rotates versions again.
    # Change this to switch models:
    model_name = "gemini-3.1-pro-preview"  # Options: "gemini-pro-latest", "gemini-3.1-pro-preview", "gemini-3.5-flash", "gemini-2.5-flash"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:{method}?key={GEMINI_API_KEY}"

    if stream:
        url += "&alt=sse"
       
    headers = {"Content-Type": "application/json"}
   
    try:
        print(f"Sending POST request to Gemini with stream={stream}")
        response = requests.post(url, json=payload, headers=headers, timeout=60, stream=stream)

        # Better error handling for quota/permission issues
        if response.status_code == 403:
            error_msg = response.text
            raise Exception(f"403 FORBIDDEN - Possible causes:\n"
                          f"1. Daily quota exceeded (Google cut free tier by 50-92% on Dec 7, 2025)\n"
                          f"2. Billing not enabled - Enable at https://console.cloud.google.com/\n"
                          f"3. API key lacks permissions\n"
                          f"Full error: {error_msg}")
        elif response.status_code == 429:
            raise Exception(f"429 RATE LIMIT - You've exceeded your quota. Wait for reset or enable billing.")

        response.raise_for_status()
        print("Received response from Gemini")
       
        if not stream:
            candidate = response.json()["candidates"][0]
            return candidate["content"]["parts"][0]["text"]
        else:
            def generate():
                for line in response.iter_lines():
                    if line:
                        decoded_line = line.decode('utf-8').strip()
                        # --- FIX 2: Only parse lines starting with 'data: ' ---
                        if decoded_line.startswith("data: "):
                            try:
                                json_content = decoded_line[6:] # Remove 'data: ' prefix
                                data = json.loads(json_content)
                                if 'candidates' in data and data['candidates']:
                                    parts = data['candidates'][0].get('content', {}).get('parts', [])
                                    if parts:
                                        text = parts[0].get('text', '')
                                        if text:
                                            yield text
                            except Exception as e:
                                # Ignore parse errors for empty/keep-alive lines
                                continue
            return generate()
    except Exception as e:
        print(f"Error in Gemini query: {str(e)}")
        raise
def create_file_search_store(api_key):
    url = f"https://generativelanguage.googleapis.com/v1beta/fileSearchStores?key={api_key}"
    payload = {"displayName": f"LeetCode Knowledge Base {int(time.time())}"}
    headers = {"Content-Type": "application/json"}
    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()["name"]
    except Exception as e:
        raise Exception(f"Failed to create File Search store: {str(e)}")
def import_file_to_store(store_name, file_name, api_key):
    url = f"https://generativelanguage.googleapis.com/v1beta/{store_name}:importFile?key={api_key}"
    payload = {
        "fileName": file_name,
        "chunkingConfig": {
            "whiteSpaceConfig": {
                "maxTokensPerChunk": 500,
                "maxOverlapTokens": 100
            }
        }
    }
    headers = {"Content-Type": "application/json"}
    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()["name"]
    except Exception as e:
        raise Exception(f"Failed to import file: {str(e)}")
def wait_for_operation(operation_name, api_key):
    while True:
        url = f"https://generativelanguage.googleapis.com/v1beta/{operation_name}?key={api_key}"
        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()
            if data.get("done"):
                if "error" in data:
                    raise Exception(data["error"])
                return
            time.sleep(5)
        except Exception as e:
            raise Exception(f"Operation failed: {str(e)}")
import hashlib
def get_file_hash(file_path):
    hasher = hashlib.md5()
    with open(file_path, 'rb') as f:
        buf = f.read()
        hasher.update(buf)
    return hasher.hexdigest()
def upload_file_to_gemini(file_path, api_key):
    config_file = "gemini_store_config.json"
    current_hash = get_file_hash(file_path)
   
    if os.path.exists(config_file):
        try:
            with open(config_file, "r") as f:
                config = json.load(f)
           
            if config.get("file_hash") == current_hash and config.get("store_name"):
                print(f"Knowledge base unchanged. Using cached Store: {config['store_name']}")
                return config['store_name']
        except Exception as e:
            print(f"Error reading cache, forcing re-upload: {e}")
    print(f"Uploading new version of: {file_path}")
    url = f"https://generativelanguage.googleapis.com/upload/v1beta/files?key={api_key}"
    file_name = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)
    mime_type = "application/json"
   
    init_headers = {
        "X-Goog-Upload-Protocol": "resumable",
        "X-Goog-Upload-Command": "start",
        "X-Goog-Upload-Header-Content-Length": str(file_size),
        "X-Goog-Upload-Header-Content-Type": mime_type,
        "Content-Type": "application/json",
    }
    init_payload = json.dumps({"file": {"display_name": file_name}})
   
    try:
        init_response = requests.post(url, headers=init_headers, data=init_payload)
        init_response.raise_for_status()
        upload_url = init_response.headers["X-Goog-Upload-URL"]
       
        upload_headers = {
            "X-Goog-Upload-Command": "upload,finalize",
            "X-Goog-Upload-Offset": "0",
            "Content-Type": mime_type,
        }
        with open(file_path, "rb") as f:
            file_data = f.read()
        upload_response = requests.put(upload_url, headers=upload_headers, data=file_data)
        upload_response.raise_for_status()
       
        file_response = upload_response.json()
        gemini_file_name = file_response["file"]["name"]
       
        store_name = create_file_search_store(api_key)
       
        operation_name = import_file_to_store(store_name, gemini_file_name, api_key)
        wait_for_operation(operation_name, api_key)
       
        with open(config_file, "w") as f:
            json.dump({"file_hash": current_hash, "store_name": store_name}, f)
           
        print(f"Upload complete. New Store cached: {store_name}")
        return store_name
    except Exception as e:
        print(f"Upload failed: {str(e)}")
        return None
# Function to handle capture completion
def handle_capture(rect, capture_widget):
    print("handle_capture called")
    global current_capture, multi_texts, multi_images
    current_capture = None
    if rect.isEmpty():
        print("rect is empty, canceling multi")
        if enter_hook:
            keyboard.remove_hotkey(enter_hook)
        multi_texts = []
        multi_images = []
        return
    print("Capturing selected region")
    img = capture_widget.screenshot_pil.crop((rect.left(), rect.top(), rect.right(), rect.bottom()))
    print("Region cropped")
    # Enhance image
    img = ImageEnhance.Contrast(img).enhance(1.5)
    img = ImageEnhance.Sharpness(img).enhance(1.5)
    print("Image enhanced")
    # Extract text using Windows OCR for Grok/DeepSeek/Local
    try:
        extracted_text = perform_ocr(img)
    except Exception as e:
        extracted_text = ""
        print(f"OCR failed: {e}")
    # Base64 for Gemini
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    image_base64 = base64.b64encode(buffer.getvalue()).decode()
    print("Text extracted and image encoded")
    multi_texts.append(extracted_text)
    multi_images.append(image_base64)
    # Continue to next capture
    start_capture()
# Function to start capture
def start_capture():
    print("Starting screen selection")
    global current_capture
    current_capture = ScreenCaptureWidget()
    print("ScreenCaptureWidget created")
    current_capture.captured.connect(lambda rect: handle_capture(rect, current_capture))
    print("captured signal connected")
# Function to start multi capture mode
def start_multi_capture():
    global multi_texts, multi_images, enter_hook, current_overlay, current_capture
    # Pressing Ctrl+Alt+S again: tear down any previous selection/overlay first,
    # then start a fresh session (so a re-press always "opens up a new one").
    if enter_hook is not None:
        try:
            keyboard.remove_hotkey(enter_hook)
        except Exception:
            pass
        enter_hook = None
    if current_capture is not None:
        try:
            current_capture.close()
        except Exception:
            pass
        current_capture = None
    if current_overlay is not None:
        try:
            current_overlay.close()
        except Exception:
            pass
        current_overlay = None
        QApplication.processEvents()  # let the old overlay vanish before the screenshot
    multi_texts = []
    multi_images = []
    enter_hook = keyboard.add_hotkey('enter', send_multi)
    start_capture()
# Function to send multi
def send_multi():
    global current_capture, enter_hook, multi_texts, multi_images
    if current_capture:
        current_capture.hide()
        current_capture = None
    if enter_hook:
        keyboard.remove_hotkey(enter_hook)
    if multi_texts:
        extracted_text = '\n\n'.join(multi_texts)
        image_base64 = multi_images[0] if multi_images else "" # Assume first image, or combine if multi
        handler.showOverlay.emit(extracted_text, image_base64)
    multi_texts = []
    multi_images = []
# Function to create and show overlay
def create_and_show_overlay(extracted_text, image_base64):
    global current_overlay
    print("Creating overlay in main thread")
    # Ensure only one overlay ever exists at a time
    if current_overlay is not None:
        try:
            current_overlay.close()
        except Exception:
            pass
        current_overlay = None
    overlay = Overlay(extracted_text=extracted_text, image_base64=image_base64)
    current_overlay = overlay
    print("Showing overlay")
    overlay.show()
    print("Overlay shown")
print("Functions defined")
# ------------------------------------------------------------------
# Crash resilience: a supervisor process relaunches the app if it dies
# ------------------------------------------------------------------
def _atomic_write_json(path, data):
    """Write JSON with tmp+fsync+os.replace so a crash can't leave a truncated file."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
def _cache_is_active():
    """True only if a session cache exists AND is flagged active (would be restored)."""
    try:
        if not os.path.exists(SESSION_CACHE):
            return False
        with open(SESSION_CACHE, "r", encoding="utf-8") as f:
            return bool(json.load(f).get("active"))
    except Exception:
        return False
def _mark_cache_inactive():
    """Flag the cached session as cleanly closed so it is NOT restored next launch."""
    try:
        if os.path.exists(SESSION_CACHE):
            with open(SESSION_CACHE, "r", encoding="utf-8") as f:
                d = json.load(f)
            d["active"] = False
            _atomic_write_json(SESSION_CACHE, d)  # atomic so a crash can't resurrect it
    except Exception:
        pass
def clean_quit():
    """Ctrl+Alt+Q: shut the whole app down on purpose (exit 0 -> no auto-restart)."""
    global current_overlay
    print("Clean quit requested (Ctrl+Alt+Q)")
    try:
        if current_overlay is not None:
            current_overlay.close()
    except Exception:
        pass
    _mark_cache_inactive()
    # Force an immediate, clean (code 0) exit so the supervisor stops and no hung
    # worker thread (blocked in a network read) can keep the process alive.
    os._exit(0)
def _message_box(title, text):
    """Show a Windows error dialog (used when the app gives up) or print elsewhere."""
    if sys.platform == "win32":
        try:
            ctypes.windll.user32.MessageBoxW(0, text, title, 0x10)  # MB_ICONERROR
            return
        except Exception:
            pass
    print(f"{title}: {text}")
def _install_crash_logging():
    """Log unhandled exceptions and native faults, then exit nonzero so the supervisor
    relaunches. In PyQt6 a custom excepthook otherwise SWALLOWS slot exceptions and the
    app keeps running corrupted - so we must exit to actually recover via restart."""
    import traceback
    log_path = os.path.join(_BASE_DIR, "leet_crash.log")
    def _hook(exc_type, exc, tb):
        try:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write("\n=== Unhandled exception ===\n")
                traceback.print_exception(exc_type, exc, tb, file=f)
        except Exception:
            pass
        try:
            traceback.print_exception(exc_type, exc, tb)
        except Exception:
            pass
        if issubclass(exc_type, KeyboardInterrupt):
            os._exit(0)   # Ctrl+C is an intentional stop
        os._exit(1)       # crash -> nonzero -> supervisor relaunches & restores the session
    sys.excepthook = _hook
    try:
        import faulthandler
        faulthandler.enable(open(os.path.join(_BASE_DIR, "leet_faulthandler.log"), "a"))
    except Exception:
        pass
def _make_kill_on_close_job():
    """A Windows Job Object (KILL_ON_JOB_CLOSE) so the child dies if the supervisor is
    killed - prevents an invisible, hotkey-grabbing orphan process. Returns (job, k32)."""
    if sys.platform != "win32":
        return None, None
    try:
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        # Declare prototypes so 64-bit HANDLEs aren't truncated to 32-bit ints.
        k32.CreateJobObjectW.restype = wintypes.HANDLE
        k32.CreateJobObjectW.argtypes = [wintypes.LPVOID, wintypes.LPCWSTR]
        k32.OpenProcess.restype = wintypes.HANDLE
        k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k32.AssignProcessToJobObject.restype = wintypes.BOOL
        k32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        k32.CloseHandle.argtypes = [wintypes.HANDLE]
        k32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        job = k32.CreateJobObjectW(None, None)
        if not job:
            return None, None
        class BASIC(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64),
                        ("PerJobUserTimeLimit", ctypes.c_int64),
                        ("LimitFlags", wintypes.DWORD),
                        ("MinimumWorkingSetSize", ctypes.c_size_t),
                        ("MaximumWorkingSetSize", ctypes.c_size_t),
                        ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.c_void_p),
                        ("PriorityClass", wintypes.DWORD),
                        ("SchedulingClass", wintypes.DWORD)]
        class IO(ctypes.Structure):
            _fields_ = [("ReadOperationCount", ctypes.c_uint64),
                        ("WriteOperationCount", ctypes.c_uint64),
                        ("OtherOperationCount", ctypes.c_uint64),
                        ("ReadTransferCount", ctypes.c_uint64),
                        ("WriteTransferCount", ctypes.c_uint64),
                        ("OtherTransferCount", ctypes.c_uint64)]
        class EXT(ctypes.Structure):
            _fields_ = [("BasicLimitInformation", BASIC), ("IoInfo", IO),
                        ("ProcessMemoryLimit", ctypes.c_size_t),
                        ("JobMemoryLimit", ctypes.c_size_t),
                        ("PeakProcessMemoryUsed", ctypes.c_size_t),
                        ("PeakJobMemoryUsed", ctypes.c_size_t)]
        info = EXT()
        info.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        k32.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info))  # 9 = ExtendedLimitInformation
        return job, k32
    except Exception as e:
        print(f"Job object setup failed (orphan protection off): {e}")
        return None, None
def run_supervisor():
    """Parent watchdog: run the app as a child and relaunch it whenever it crashes.

    Because the child is a SEPARATE process, this survives hard crashes (unhandled
    exceptions, PyQt/C-level aborts, segfaults, the OS killing the child). On restart
    the session cache brings every AI response back. A clean quit (exit code 0, e.g.
    Ctrl+Alt+Q) stops the loop. Safeguards: a kill-on-close Job Object stops the child
    from outliving the supervisor as an invisible ghost; a session cache that keeps
    crashing on restore is quarantined; a permanently-failing app gives up visibly
    instead of looping forever.
    """
    import subprocess
    if getattr(sys, "frozen", False):
        child_cmd = [sys.executable]                       # packaged .exe
    else:
        child_cmd = [sys.executable, os.path.abspath(__file__)]
    job, k32 = _make_kill_on_close_job()
    backoff = 1
    short_crashes = 0     # consecutive crashes that died in <15s (a crash loop)
    quarantined = False
    while True:
        env = dict(os.environ, LEET_CHILD="1")
        started = time.monotonic()
        code = -1
        try:
            proc = subprocess.Popen(child_cmd, env=env, cwd=_BASE_DIR)
        except KeyboardInterrupt:
            print("Supervisor: interrupted, stopping.")
            break
        except Exception as e:
            print(f"Supervisor: failed to launch child: {e}")  # transient -> treat as crash
        else:
            if job is not None and k32 is not None:
                try:
                    hproc = k32.OpenProcess(0x0100 | 0x0001, False, proc.pid)  # SET_QUOTA | TERMINATE
                    if hproc:
                        k32.AssignProcessToJobObject(job, hproc)
                        k32.CloseHandle(hproc)
                except Exception:
                    pass
            try:
                proc.wait()
            except KeyboardInterrupt:
                print("Supervisor: interrupted, stopping.")
                try:
                    proc.terminate()
                except Exception:
                    pass
                break
            code = proc.returncode
        ran = time.monotonic() - started
        if code == 0:
            print("Supervisor: app exited cleanly; not restarting.")
            break
        if ran < 15:
            short_crashes += 1
        else:
            short_crashes = 0
            backoff = 1          # it was healthy for a while -> treat this as a fresh crash
            quarantined = False  # re-arm quarantine so a NEW poison session can be caught later
        # The session we keep restoring may itself be what crashes us. Only quarantine an
        # ACTIVE cache (one that would actually be restored) so we never discard an innocent
        # already-closed session for a crash caused by something else.
        if short_crashes >= 3 and not quarantined and _cache_is_active():
            try:
                os.replace(SESSION_CACHE, SESSION_CACHE + ".bad")
                print("Supervisor: quarantined a poison session cache -> session_cache.json.bad")
            except Exception:
                pass
            quarantined = True
            short_crashes = 0
            backoff = 1
            continue  # relaunch immediately with a clean slate
        # Even after quarantine it keeps fast-crashing -> a broken install; give up visibly.
        if short_crashes >= 5:
            _message_box("LeetCode helper stopped",
                         "The app keeps crashing on startup and has stopped auto-restarting.\n"
                         "See leet_crash.log next to the script.")
            print("Supervisor: too many rapid crashes; giving up.")
            break
        print(f"Supervisor: app crashed (exit {code}) after {ran:.0f}s; restarting in {backoff}s")
        try:
            time.sleep(backoff)
        except KeyboardInterrupt:
            print("Supervisor: interrupted during backoff, stopping.")
            break
        backoff = min(backoff * 2, 30)  # cap the crash-loop rate
if __name__ == "__main__":
    # The parent process supervises; the child (LEET_CHILD=1) runs the real GUI so a
    # crash is auto-relaunched. Set LEET_NO_SUPERVISOR=1 to run the app directly.
    if os.environ.get("LEET_CHILD") != "1" and os.environ.get("LEET_NO_SUPERVISOR") != "1":
        run_supervisor()
        sys.exit(0)
    _install_crash_logging()
    print("Entering main block")
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)  # stay alive after an overlay closes, so Ctrl+Alt+S keeps working
    print("QApplication created")
    handler = HotkeyHandler()
    handler.startCapture.connect(start_multi_capture)
    handler.showOverlay.connect(create_and_show_overlay)
    handler.quitApp.connect(clean_quit)
    keyboard.add_hotkey("ctrl+alt+s", lambda: handler.startCapture.emit())
    keyboard.add_hotkey("ctrl+alt+q", lambda: handler.quitApp.emit())
    print("Hotkeys registered: ctrl+alt+s (capture / new), ctrl+alt+q (quit)")
    # --- Crash recovery: if we died with an overlay open, bring that session back ---
    try:
        if os.path.exists(SESSION_CACHE):
            with open(SESSION_CACHE, "r", encoding="utf-8") as f:
                _cache = json.load(f)
            if _cache.get("active"):
                print("Restoring previous session after crash/restart")
                current_overlay = Overlay(restore_data=_cache)
                current_overlay.show()
    except Exception as e:
        print(f"Session restore failed: {e}")
    print("Entering app.exec()")
    sys.exit(app.exec())