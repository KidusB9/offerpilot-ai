"""
company_launcher.py — pick a company, generate its Q&A DB, launch the copilot.
=============================================================================

A small PyQt6 launcher that ties the flow together:

    click a company  (or type Company + Role)  ->  "Generate & Launch"
        1. generate_company_qa.generate(company, role)  writes
           <slug>_qa.json + <slug>_profile.json next to the scripts
        2. interview_copilot_company.py <slug> is launched as a subprocess
           (its own crash-supervisor keeps it alive)

Generation runs on a worker thread so the UI never freezes, and the launcher
window applies the SAME screen-capture exclusion the copilot uses, so it's also
invisible to Zoom / Teams / Meet / OBS.

Run:  python company_launcher.py
"""

import os
import sys
import subprocess

from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QLineEdit,
)
from PyQt6.QtCore import Qt, QObject, pyqtSignal, QThread

# Reuse the copilot's screen-capture protection + the generator, untouched.
from interview_copilot import exclude_from_capture
import generate_company_qa as gen


def _script_dir():
    return os.path.dirname(os.path.abspath(__file__))


# ~10 popular companies with a sensible default role each (used if Role is blank).
COMPANIES = [
    ("JPMorgan Chase", "Software Engineer II"),
    ("Google", "Software Engineer"),
    ("Amazon", "Software Development Engineer"),
    ("Meta", "Software Engineer"),
    ("Microsoft", "Software Engineer"),
    ("Goldman Sachs", "Software Engineer"),
    ("Citadel", "Software Engineer"),
    ("Stripe", "Software Engineer"),
    ("Neuberger Berman", "Software Engineer"),
    ("Apple", "Software Engineer"),
]


# --------------------------------------------------------------------------- #
#  WORKER  (generation on a background thread)                                  #
# --------------------------------------------------------------------------- #
class GenWorker(QObject):
    status = pyqtSignal(str)
    done = pyqtSignal(str, str)      # (slug, qa_path)
    failed = pyqtSignal(str)

    def __init__(self, company, role):
        super().__init__()
        self.company = company
        self.role = role

    def run(self):
        try:
            self.status.emit(f"Generating Q&A for {self.company}…")
            qa_path, _profile = gen.generate(self.company, self.role, out_dir=_script_dir())
            slug = gen.slugify(self.company)
            self.done.emit(slug, qa_path)
        except Exception as e:
            self.failed.emit(str(e))


# --------------------------------------------------------------------------- #
#  LAUNCHER WINDOW                                                              #
# --------------------------------------------------------------------------- #
class Launcher(QWidget):
    def __init__(self):
        super().__init__()
        self._thread = None
        self._worker = None
        self._busy = False

        self.setWindowTitle("OfferPilot — Company Launcher")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        self._build_ui()

        # Apply screen-capture exclusion before the first frame (same as the copilot).
        self.winId()
        exclude_from_capture(self)

    def _build_ui(self):
        self.setStyleSheet("""
            QWidget { background:#0b0f14; color:#dfe7ef; font-family:'Segoe UI'; }
            QLabel#title { color:#8be9fd; font-size:20px; font-weight:700; }
            QLabel#sub { color:#7d8b99; font-size:12px; }
            QLabel#status { color:#38e08b; font-size:12px; font-weight:600; }
            QLineEdit { background:#060a10; color:#e6edf3; border:1px solid #26313f;
                        border-radius:8px; padding:8px; font-size:13px; }
            QPushButton { background:#161e2a; color:#cfe0ee; border:1px solid #2b3b4e;
                        border-radius:8px; padding:8px 12px; font-size:13px; }
            QPushButton:hover { background:#233247; }
            QPushButton#go { background:#2f7bd0; color:white; border:1px solid #8be9fd;
                        font-weight:700; padding:10px 14px; }
            QPushButton#go:hover { background:#3a8ae6; }
        """)
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(12)

        title = QLabel("🎧  Interview Copilot — Company Launcher")
        title.setObjectName("title")
        root.addWidget(title)
        sub = QLabel("Pick a company (or type your own), then Generate & Launch. "
                     "Files are written next to this app; existing apps are untouched.")
        sub.setObjectName("sub")
        sub.setWordWrap(True)
        root.addWidget(sub)

        # Company shortcut buttons.
        grid = QGridLayout()
        grid.setSpacing(8)
        for i, (name, role) in enumerate(COMPANIES):
            b = QPushButton(name)
            b.setToolTip(f"Generate & launch: {name} — {role}")
            b.clicked.connect(lambda _, n=name, r=role: self._on_company_button(n, r))
            grid.addWidget(b, i // 2, i % 2)
        root.addLayout(grid)

        # Free-text company + role.
        form = QHBoxLayout()
        form.setSpacing(8)
        self.company_in = QLineEdit()
        self.company_in.setPlaceholderText("Company (e.g. Snowflake)")
        self.role_in = QLineEdit()
        self.role_in.setPlaceholderText("Role (e.g. Software Engineer)")
        form.addWidget(self.company_in, 3)
        form.addWidget(self.role_in, 3)
        root.addLayout(form)

        self.go = QPushButton("Generate & Launch")
        self.go.setObjectName("go")
        self.go.clicked.connect(self._on_go)
        root.addWidget(self.go)

        self.status = QLabel("Ready.")
        self.status.setObjectName("status")
        root.addWidget(self.status)

        self.resize(560, 460)

    # ------------------------------------------------------------ actions -- #
    def _on_company_button(self, name, default_role):
        self.company_in.setText(name)
        if not self.role_in.text().strip():
            self.role_in.setText(default_role)
        self._start(name, self.role_in.text().strip() or default_role)

    def _on_go(self):
        company = self.company_in.text().strip()
        role = self.role_in.text().strip() or "Software Engineer"
        if not company:
            self._set_status("Enter a company name (or click one above).", ok=False)
            return
        self._start(company, role)

    def _start(self, company, role):
        if self._busy:
            self._set_status("Still working — one moment…", ok=False)
            return
        self._busy = True
        self.go.setEnabled(False)
        self._set_status(f"Generating Q&A for {company}…")

        self._thread = QThread(self)
        self._worker = GenWorker(company, role)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.status.connect(lambda m: self._set_status(m))
        self._worker.done.connect(self._on_generated)
        self._worker.failed.connect(self._on_failed)
        # Clean up the thread when the worker signals either outcome.
        self._worker.done.connect(self._thread.quit)
        self._worker.failed.connect(self._thread.quit)
        self._thread.start()

    def _on_generated(self, slug, qa_path):
        self._set_status(f"Launching copilot for {slug}…")
        try:
            script = os.path.join(_script_dir(), "interview_copilot_company.py")
            # Fresh env carrying the slug too, so either mechanism resolves it.
            env = dict(os.environ, OFFERPILOT_COMPANY=slug)
            subprocess.Popen([sys.executable, script, slug],
                             cwd=_script_dir(), env=env)
            self._set_status(f"Launched: {slug}  ·  wrote {os.path.basename(qa_path)}")
        except Exception as e:
            self._set_status(f"Launch failed: {e}", ok=False)
        finally:
            self._busy = False
            self.go.setEnabled(True)

    def _on_failed(self, msg):
        # generate() itself never fails (it falls back to a template), so this is a
        # hard error — surface it plainly.
        self._set_status(f"Generation error: {msg}", ok=False)
        self._busy = False
        self.go.setEnabled(True)

    def _set_status(self, text, ok=True):
        self.status.setText(text)
        self.status.setStyleSheet(
            "color:#38e08b; font-size:12px; font-weight:600;" if ok else
            "color:#ff6b6b; font-size:12px; font-weight:600;")


def main():
    app = QApplication(sys.argv)
    win = Launcher()
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
