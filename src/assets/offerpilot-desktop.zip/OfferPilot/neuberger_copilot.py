"""
Neuberger Copilot — REAL-TIME interview assistant for Kidus.
=============================================================================
Neuberger Berman · Application Developer II — Private Markets Technology
Front Office Technology, New York · interviewer: Larry Green, FRM.

No windows, no countdowns, no waiting. It listens CONTINUOUSLY and streams:

  interviewer speaks  ->  words transcribe LIVE (Vosk, offline, on-device)
                      ->  the moment they stop, the AI answer streams instantly
                      ->  the Q&A page auto-scrolls to the matching prepared answer

STACK
  - STT      : Vosk streaming recognizer (real-time partial + final results,
               fully offline, no per-clip upload latency).
  - Capture  : sounddevice RawInputStream in SHARED mode (never blocks Zoom/Teams).
  - AI       : Grok + DeepSeek + Gemini, streamed in parallel, GROUNDED (RAG) in
               your Neuberger Berman prep playbook so answers are in your voice.
  - Q&A page : the real doc content (Q + answer + code), auto-scrolling.
  - Code     : SQL / Python, rendered in a syntax-highlighted module (Pygments).

CONTROLS
  Hold  M            -> pause / resume listening
  Hold  P            -> toggle full-window transparency (ghost mode)
  Drag any edge      -> resize (left/right edges = horizontal double-arrow)
  Type box + Enter   -> ask manually (test without speaking)
  Title bar  —       -> collapse to the title bar (click again / double-click to expand)
  Title bar  ▢ / ✕   -> maximize / close
  Ctrl+Alt+1/2/3     -> Grok / DeepSeek / Gemini
  Esc                -> quit

SCREEN-SHARE INVISIBILITY (Windows)
  The window calls SetWindowDisplayAffinity(WDA_EXCLUDEFROMCAPTURE): it stays
  fully visible on your own monitor but is composited OUT of the frame that
  screen-capture software receives — so it's absent from Zoom, Teams, Google
  Meet (browser share), Discord, OBS, Snipping Tool and PrintScreen. Protection
  is applied before the first frame is painted and re-asserted on a timer so it
  self-heals if Qt ever recreates the native window. Qt.Tool also keeps it out of
  the taskbar / Alt-Tab so its PRESENCE isn't exposed in a full-desktop share
  (Ctrl+Alt+H hides / restores it). A green shield in the title bar confirms it's
  ON; a warning banner appears if protection is only partial (WDA_MONITOR
  black-box, amber) or fails (red), so you're never falsely reassured.

If the app ever crashes it relaunches itself automatically.

Run:  python neuberger_copilot.py
"""

import sys
import os
import ctypes
import re
import html
import json
import queue
import threading

import requests
import numpy as np
import sounddevice as sd

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit, QTextBrowser, QLabel, QLineEdit,
)
from PyQt6.QtCore import Qt, QObject, pyqtSignal, QTimer, QRect, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QGuiApplication, QCursor

import keyboard
from rapidfuzz import process, fuzz

try:
    from pygments import highlight as _pyg_highlight
    from pygments.lexers import get_lexer_by_name
    from pygments.formatters import HtmlFormatter
    _PYGMENTS = True
except Exception:
    _PYGMENTS = False


# --------------------------------------------------------------------------- #
#  SCREEN-CAPTURE INVISIBILITY  (Windows)                                      #
# --------------------------------------------------------------------------- #
# SetWindowDisplayAffinity lets a top-level window opt out of screen capture.
#   WDA_EXCLUDEFROMCAPTURE (0x11): the window is completely excluded from any
#       capture (Zoom, Teams, Meet, Discord, OBS, Snip, PrintScreen, etc.) yet
#       stays fully visible on the user's own physical monitor. Requires Windows
#       10 version 2004 (build 19041) or newer.
#   WDA_MONITOR (0x01): fallback for older builds — the window still can't be
#       captured, but it appears as a solid black rectangle in the capture.
WDA_NONE = 0x00000000
WDA_MONITOR = 0x00000001
WDA_EXCLUDEFROMCAPTURE = 0x00000011


def exclude_from_capture(widget):
    """Make a Qt widget's top-level window invisible to screen capture on Windows.

    Safe to call repeatedly (e.g. from showEvent or a timer) — it is idempotent
    and does not log, so the caller can re-assert it cheaply for self-healing.
    Returns one of:
        "excluded" — fully hidden from capture (WDA_EXCLUDEFROMCAPTURE)
        "monitor"  — fallback: window shows as a solid BLACK BOX in captures
        "failed"   — no protection applied; the window IS capturable
    """
    if sys.platform != "win32":
        return "failed"
    try:
        hwnd = int(widget.winId())
    except Exception:
        return "failed"
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        # BOOL is a 4-byte int; use c_int and test != 0 to match the Win32 contract.
        user32.SetWindowDisplayAffinity.restype = ctypes.c_int
        user32.SetWindowDisplayAffinity.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        # Prefer full exclusion (Win10 2004+); fall back to black-out on older builds.
        if user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE) != 0:
            return "excluded"
        if user32.SetWindowDisplayAffinity(hwnd, WDA_MONITOR) != 0:
            return "monitor"
        return "failed"
    except Exception:
        return "failed"


# --------------------------------------------------------------------------- #
#  API KEYS + MODELS                                                           #
# --------------------------------------------------------------------------- #
from offerpilot_keys import GROK_API_KEY, DEEPSEEK_API_KEY, GEMINI_API_KEY

GROK_MODEL = "grok-4-fast-reasoning"
DEEPSEEK_MODEL = "deepseek-chat"
GEMINI_MODEL = "gemini-2.5-flash"
MODELS = ["Grok", "DeepSeek", "Gemini"]

SAMPLE_RATE = 16000
MIN_WORDS_TO_FIRE = 3       # ignore "yeah", "okay" — need a real utterance
FIRE_DEBOUNCE_MS = 700      # group a multi-pause question, then fire once
VOSK_MODEL_DIR = "vosk-model-small-en-us-0.15"
# Knowledge base: qa = doc-derived (make_qa_nb.py); qa_extra = hand-added.
QA_FILES = ("neuberger_qa.json", "neuberger_qa_extra.json")
DEFAULT_CODE_LANG = "sql"   # this role is SQL Server + Python, not C#
GHOST_OPACITY = 0.20        # opacity when hold-P transparency mode is on
RESIZE_GRIP = 7             # px border on every edge for drag-resize
HOLD_MS = 400               # how long M / P must be held to trigger

SYSTEM_PROMPT = (
    "You are the real-time interview co-pilot for KIDUS BERHAN during a live "
    "Neuberger Berman 'Application Developer II — Private Markets Technology' "
    "interview (Front Office Technology, New York). The interviewer is LARRY "
    "GREEN, an SVP Lead Technologist with a Finance degree and the FRM "
    "certification — he speaks risk and portfolio math fluently, probes every "
    "resume claim to bedrock, and rewards precise honesty over bluffing. The "
    "user message is a LIVE transcription of the interviewer and may contain "
    "small transcription errors.\n\n"
    "Do this:\n"
    "1. Infer the actual question being asked.\n"
    "2. Write a first-person answer KIDUS can say OUT LOUD immediately — confident, "
    "concrete, in his voice. Ground it in his background and the REFERENCE answers "
    "provided: front-office portfolio construction & exposure analytics at CME "
    "Group; the UROCK enterprise data platform at UES (SQL Server schemas, "
    "window functions, performance-tuned stored procedures, Python/pandas "
    "ingestion pipelines, portfolio-level aggregation); an AI proposal pipeline; "
    "OSF HealthCare data science; and he's relocating to New York (already "
    "decided — never hedge on relocation). Think like a front-office data "
    "engineer: correctness of the numbers first, then point-in-time / bitemporal "
    "storage, idempotent loads, reconciliation, lineage, and quarantine-don't-"
    "half-load. Use correct private-markets vocabulary (commitment vs. called vs. "
    "unfunded, NAV, exposure = NAV + unfunded, IRR vs. TVPI, TVPI = DPI + RVPI, "
    "the J-curve, look-through exposure, vintage year, capital calls). When a fact "
    "is a domain gap, say 'I don't know, but here's how I'd reason about it' — that "
    "scores with an FRM; a confident wrong answer ends the interview.\n"
    "3. If code is expected, DO NOT jump straight to code. Larry publicly grades "
    "on this: candidates who start typing in the first five minutes fail; a solid "
    "plan beats a complete solution to the wrong problem. So structure the answer "
    "as things KIDUS says OUT LOUD, in this exact order, before any code:\n"
    "   a. RESTATE the problem in one sentence and confirm it ('So: … — did I get "
    "that right?'), naming the 1-2 assumptions or clarifying questions that matter "
    "(clean input? volume? duplicates/ties? exact output shape?).\n"
    "   b. WORK A TINY EXAMPLE by hand — two or three sample rows in, expected rows "
    "out — so the logic is obvious before the syntax.\n"
    "   c. STATE THE PLAN as short numbered steps ('1) … 2) … 3) …').\n"
    "   d. THEN write the OPTIMAL, correct solution in a ```sql (SQL Server T-SQL) "
    "or ```python (pandas) fenced block. Justify the KEY decisions in a few words "
    "as you go — the data structure / window frame, not the syntax ('keyed by tuple "
    "because the output is flat'). If the optimal isn't obvious, name the naive "
    "version out loud first, then the optimization ('simple O(n·m) first, then a set "
    "lookup if we need it') — a communicated brute force beats a silent clever one.\n"
    "   e. AFTER the code, VERIFY it OUT LOUD — this is the exact step Larry grades "
    "and most candidates skip, so always include it for a code question, kept tight "
    "(a line or two each):\n"
    "      - DRY-RUN the 2-3 sample rows from step (b) through the code and show they "
    "produce the expected output.\n"
    "      - ENUMERATE the edge cases and how the code handles each — empty input, "
    "header-only, one row, duplicate / tied keys, NULLs, a malformed row, negative "
    "amounts, divide-by-zero (for SQL: empty partitions, same-date ties, "
    "restatements).\n"
    "      - Name the TEST you'd write: 'I'd parametrize pytest fixtures for clean, "
    "dirty, and empty inputs and pin the output to known totals,' and give one "
    "concrete assert — writing even one live test is the differentiator.\n"
    "      - One line on the supporting index and the window frame (ROWS vs RANGE and "
    "why), plus the complexity.\n"
    "Finance-correctness reflexes to weave in where they apply: never compare money "
    "with '=' — use a tolerance (abs(a-b) > max(abs_tol, rel_tol*abs(b))); ledgers use "
    "Decimal or integer cents, analytics use floats rounded at the boundary; forward-"
    "fill only, never backfill (backfilling a future NAV backward is lookahead bias); "
    "group before you shift/fill so one fund's data can't bleed into another; sort "
    "report output by absolute size descending (how ops triages); row counts before "
    "and after every join; ROW_NUMBER + a tiebreaker for latest-per-entity. NEVER use "
    "NOLOCK as a tuning tip and NEVER SELECT * in production examples.\n\n"
    "For a NON-code question, answer directly and conversationally — the restate/"
    "example/plan/verify structure is ONLY for coding or query-writing questions.\n"
    "Output ONLY the answer. No 'what they're testing', no coaching, no preamble. "
    "Keep it tight and speakable."
)


# --------------------------------------------------------------------------- #
#  CODE / MARKDOWN RENDERING  ("perfect code module")                          #
# --------------------------------------------------------------------------- #
def code_block_html(code, lang):
    lang = (lang or DEFAULT_CODE_LANG).lower()
    if lang in ("cs", "c#"):
        lang = "csharp"
    if lang in ("py",):
        lang = "python"
    if _PYGMENTS:
        try:
            lexer = get_lexer_by_name(lang)
        except Exception:
            lexer = get_lexer_by_name(DEFAULT_CODE_LANG)
        inner = _pyg_highlight(code, lexer, HtmlFormatter(noclasses=True, nowrap=True))
        return (
            "<div style='background:#0b0f14; border:1px solid #26313f; border-radius:8px; "
            "padding:10px; margin:8px 0;'>"
            f"<pre style='margin:0; font-family:Consolas,\"Cascadia Code\"; font-size:12px; "
            f"color:#e6edf3; white-space:pre-wrap;'>{inner}</pre></div>"
        )
    esc = html.escape(code)
    return (
        "<pre style='background:#0b0f14; color:#e6edf3; border:1px solid #26313f; "
        "border-radius:8px; padding:10px; margin:8px 0; font-family:Consolas; "
        f"font-size:12px; white-space:pre-wrap;'>{esc}</pre>"
    )


def render_prose(text):
    text = (text or "").strip()
    if not text:
        return ""
    esc = html.escape(text)
    esc = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', esc)
    esc = re.sub(r'`([^`]+)`',
                 r"<span style='font-family:Consolas; background:#11202b; padding:0 3px; border-radius:3px;'>\1</span>",
                 esc)
    esc = esc.replace("\n", "<br>")
    return f"<div style='margin:6px 0; line-height:1.55; color:#e6edf3; font-size:13px;'>{esc}</div>"


def render_markdown(md):
    """Render AI markdown -> HTML, with fenced code blocks in the code module."""
    parts = re.split(r'```([A-Za-z0-9#+]*)\n(.*?)```', md, flags=re.S)
    out, i = [], 0
    while i < len(parts):
        out.append(render_prose(parts[i]))
        if i + 2 < len(parts):
            out.append(code_block_html(parts[i + 2], parts[i + 1] or DEFAULT_CODE_LANG))
            i += 3
        else:
            break
    return "".join(out)


# --------------------------------------------------------------------------- #
#  KNOWLEDGE BASE  (real doc content, auto-scrolling page + RAG)               #
# --------------------------------------------------------------------------- #
def _script_dir():
    return os.path.dirname(os.path.abspath(__file__))


def preprocess(t):
    return re.sub(r'[^\w\s]', ' ', (t or "").lower())


class Knowledge:
    def __init__(self):
        self.items = []
        self.searchable = []
        self._load()

    def _load(self):
        bases = []
        for b in (os.getcwd(), _script_dir()):
            if b not in bases:
                bases.append(b)
        # neuberger_qa.json = doc-derived; neuberger_qa_extra.json = hand-added.
        for name in QA_FILES:
            for base in bases:
                p = os.path.join(base, name)
                if os.path.exists(p):
                    self._load_file(p)
                    break
        if not self.items:
            print(f"No {QA_FILES[0]} found.")
        else:
            print(f"Loaded {len(self.items)} Q&A entries.")

    def _load_file(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"Failed to read {path}: {e}")
            return
        for it in data.get("questions", []):
            q = it.get("question", "").strip()
            if not q:
                continue
            # widen matching with any provided keywords
            kw = " ".join(it.get("keywords", []))
            self.items.append({
                "section": it.get("section", ""),
                "q": q,
                "a": it.get("answer", "").strip(),
                "code": it.get("code", "").strip(),
                "lang": it.get("lang", DEFAULT_CODE_LANG),
            })
            self.searchable.append(preprocess(q + " " + kw))

    def match(self, text):
        if not self.searchable or not text.strip():
            return None, 0
        best = process.extractOne(preprocess(text), self.searchable, scorer=fuzz.token_set_ratio)
        if not best:
            return None, 0
        _t, score, idx = best
        return (idx, score) if score >= 55 else (None, score)

    def retrieve(self, text, k=3):
        if not self.searchable or not text.strip():
            return []
        res = process.extract(preprocess(text), self.searchable, scorer=fuzz.token_set_ratio, limit=k)
        return [self.items[idx] for _t, sc, idx in res if sc >= 40]

    def build_html(self, active_idx=None):
        rows = ["<div style='font-family:Segoe UI;'>"]
        last_section = None
        for i, it in enumerate(self.items):
            if it["section"] != last_section:
                last_section = it["section"]
                rows.append(f"<div style='color:#7fd7ff; font-size:14px; font-weight:700; "
                            f"margin:14px 0 6px 0;'>&#9670; {html.escape(it['section'])}</div>")
            active = (i == active_idx)
            bg = "#12452f" if active else "#0e141b"
            border = "#38e08b" if active else "#243141"
            qcol = "#8be9fd" if active else "#6cc4e0"
            marker = "&#9656; " if active else ""
            rows.append(f"<a name='q{i}'></a>")
            body = render_prose(it["a"])
            if it["code"]:
                body += code_block_html(it["code"], it["lang"])
            rows.append(
                f"<table width='100%' cellpadding='10' cellspacing='0' "
                f"style='margin:0 0 10px 0; border:1px solid {border};' bgcolor='{bg}'><tr><td>"
                f"<span style='color:{qcol}; font-size:13px;'><b>{marker}{html.escape(it['q'])}</b></span>"
                f"<br>{body}</td></tr></table>"
            )
        rows.append("</div>")
        return "\n".join(rows)


# --------------------------------------------------------------------------- #
#  REAL-TIME STREAMING STT  (Vosk)                                             #
# --------------------------------------------------------------------------- #
class VoskStreamer:
    def __init__(self, on_partial, on_final, on_level, on_error):
        self.on_partial, self.on_final = on_partial, on_final
        self.on_level, self.on_error = on_level, on_error
        self.q = queue.Queue()
        self.running = False
        self.paused = False
        self.stream = None
        self.rec = None

    def start(self):
        try:
            import vosk
            model_path = None
            for base in (os.getcwd(), _script_dir()):
                p = os.path.join(base, VOSK_MODEL_DIR)
                if os.path.isdir(p):
                    model_path = p
                    break
            if not model_path:
                self.on_error(f"Vosk model '{VOSK_MODEL_DIR}' not found next to the app.")
                return
            vosk.SetLogLevel(-1)
            self.rec = vosk.KaldiRecognizer(vosk.Model(model_path), SAMPLE_RATE)
            self.running = True
            self.stream = sd.RawInputStream(samplerate=SAMPLE_RATE, blocksize=4000,
                                            dtype="int16", channels=1, callback=self._cb)
            self.stream.start()
            threading.Thread(target=self._loop, daemon=True).start()
        except Exception as e:
            self.on_error(f"STT init failed: {e}")

    def _cb(self, indata, frames, time_info, status):
        if self.paused:
            return
        b = bytes(indata)
        self.q.put(b)
        try:
            self.on_level(int(np.abs(np.frombuffer(b, np.int16)).max()))
        except Exception:
            pass

    def _loop(self):
        while self.running:
            try:
                data = self.q.get(timeout=0.4)
            except queue.Empty:
                continue
            if self.paused:
                continue
            try:
                if self.rec.AcceptWaveform(data):
                    txt = json.loads(self.rec.Result()).get("text", "").strip()
                    if txt:
                        self.on_final(txt)
                else:
                    part = json.loads(self.rec.PartialResult()).get("partial", "").strip()
                    self.on_partial(part)
            except Exception:
                continue

    def set_paused(self, val):
        self.paused = val

    def stop(self):
        self.running = False
        try:
            if self.stream:
                self.stream.stop()
                self.stream.close()
        except Exception:
            pass


# --------------------------------------------------------------------------- #
#  AI ANSWER FUNCTIONS  (streaming)                                            #
# --------------------------------------------------------------------------- #
def _stream_openai(url, model, key, messages):
    payload = {"model": model, "messages": messages, "temperature": 0.4,
               "max_tokens": 1600, "stream": True}
    r = requests.post(url, json=payload, timeout=(10, 60), stream=True,
                      headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    r.raise_for_status()
    for line in r.iter_lines():
        if not line:
            continue
        line = line.decode("utf-8")
        if line.startswith("data: "):
            body = line[6:]
            if body.strip() == "[DONE]":
                break
            try:
                d = json.loads(body)["choices"][0].get("delta", {}).get("content", "")
                if d:
                    yield d
            except Exception:
                continue


def query_grok(m):
    return _stream_openai("https://api.x.ai/v1/chat/completions", GROK_MODEL, GROK_API_KEY, m)


def query_deepseek(m):
    return _stream_openai("https://api.deepseek.com/chat/completions", DEEPSEEK_MODEL, DEEPSEEK_API_KEY, m)


def query_gemini(messages):
    system, contents = "", []
    for m in messages:
        if m["role"] == "system":
            system = m["content"]
            continue
        contents.append({"role": "user" if m["role"] == "user" else "model",
                         "parts": [{"text": m["content"]}]})
    if system and contents:
        contents[0]["parts"][0]["text"] = f"System Instruction: {system}\n\n" + contents[0]["parts"][0]["text"]
    payload = {"contents": contents, "generationConfig": {"temperature": 0.3, "maxOutputTokens": 1600}}
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"{GEMINI_MODEL}:streamGenerateContent?key={GEMINI_API_KEY}&alt=sse")
    r = requests.post(url, json=payload, timeout=(10, 60), stream=True,
                      headers={"Content-Type": "application/json"})
    if r.status_code in (403, 429):
        raise Exception(f"Gemini {r.status_code} (quota/permission).")
    r.raise_for_status()
    for line in r.iter_lines():
        if not line:
            continue
        line = line.decode("utf-8").strip()
        if line.startswith("data: "):
            try:
                parts = json.loads(line[6:])["candidates"][0].get("content", {}).get("parts", [])
                if parts and parts[0].get("text"):
                    yield parts[0]["text"]
            except Exception:
                continue


AI_FUNCS = {"Grok": query_grok, "DeepSeek": query_deepseek, "Gemini": query_gemini}


# --------------------------------------------------------------------------- #
#  SIGNALS                                                                     #
# --------------------------------------------------------------------------- #
class Comm(QObject):
    partial = pyqtSignal(str)
    final = pyqtSignal(str)
    level = pyqtSignal(int)
    stt_error = pyqtSignal(str)
    ai_started = pyqtSignal(int, str)
    ai_chunk = pyqtSignal(int, str, str)
    ai_error = pyqtSignal(int, str, str)
    m_pressed = pyqtSignal()
    m_released = pyqtSignal()
    p_pressed = pyqtSignal()
    p_released = pyqtSignal()
    switch_model = pyqtSignal(str)   # marshal Ctrl+Alt+1/2/3 onto the GUI thread
    toggle_vis = pyqtSignal()        # marshal Ctrl+Alt+H onto the GUI thread


# --------------------------------------------------------------------------- #
#  RESIZABLE FRAME  (drag any edge to resize — left/right/top/bottom/corners)  #
# --------------------------------------------------------------------------- #
class ResizableFrame(QWidget):
    """A GRIP-wide transparent border around the content. Hovering an edge shows
    the double-arrow cursor; dragging resizes the window on that edge."""

    def __init__(self, win):
        super().__init__()
        self._win = win
        self._edge = ""
        self._press = None
        self._geom = None
        self.setMouseTracking(True)

    def _edges_at(self, pos):
        r, g = self.rect(), RESIZE_GRIP
        parts = []
        if pos.y() <= g:
            parts.append("top")
        elif pos.y() >= r.height() - g:
            parts.append("bottom")
        if pos.x() <= g:
            parts.append("left")
        elif pos.x() >= r.width() - g:
            parts.append("right")
        return "-".join(parts)

    def _cursor_for(self, edge):
        return {
            "left": Qt.CursorShape.SizeHorCursor, "right": Qt.CursorShape.SizeHorCursor,
            "top": Qt.CursorShape.SizeVerCursor, "bottom": Qt.CursorShape.SizeVerCursor,
            "top-left": Qt.CursorShape.SizeFDiagCursor, "bottom-right": Qt.CursorShape.SizeFDiagCursor,
            "top-right": Qt.CursorShape.SizeBDiagCursor, "bottom-left": Qt.CursorShape.SizeBDiagCursor,
        }.get(edge, Qt.CursorShape.ArrowCursor)

    def mouseMoveEvent(self, e):
        if self._edge and (e.buttons() & Qt.MouseButton.LeftButton):
            self._do_resize(e.globalPosition().toPoint())
            return
        self.setCursor(QCursor(self._cursor_for(self._edges_at(e.position().toPoint()))))

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._edge = self._edges_at(e.position().toPoint())
            if self._edge:
                self._press = e.globalPosition().toPoint()
                self._geom = self._win.geometry()
                e.accept()

    def mouseReleaseEvent(self, e):
        self._edge = ""

    def _do_resize(self, gp):
        d = gp - self._press
        g = QRect(self._geom)
        mw, mh = 680, 460
        if "left" in self._edge:
            new_left = self._geom.left() + d.x()
            if self._geom.right() - new_left >= mw:
                g.setLeft(new_left)
        if "right" in self._edge:
            g.setRight(max(self._geom.left() + mw, self._geom.right() + d.x()))
        if "top" in self._edge:
            new_top = self._geom.top() + d.y()
            if self._geom.bottom() - new_top >= mh:
                g.setTop(new_top)
        if "bottom" in self._edge:
            g.setBottom(max(self._geom.top() + mh, self._geom.bottom() + d.y()))
        self._win.setGeometry(g)


# --------------------------------------------------------------------------- #
#  TITLE BAR  (custom, with min / max / close)                                 #
# --------------------------------------------------------------------------- #
class TitleBar(QWidget):
    def __init__(self, win):
        super().__init__()
        self._win = win
        self._drag = None
        self.setFixedHeight(40)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 0, 8, 0)
        lay.setSpacing(8)

        title = QLabel("🎧  Neuberger Copilot")
        title.setStyleSheet("font-size:15px; font-weight:700; color:#8be9fd;")
        lay.addWidget(title)

        self.status = QLabel("● LIVE")
        self.status.setStyleSheet("color:#38e08b; font-size:12px; font-weight:600;")
        lay.addWidget(self.status)

        self.meter = QLabel("▁▁▁▁▁▁▁")
        self.meter.setStyleSheet("color:#3a4652; font-size:12px;")
        lay.addWidget(self.meter)
        lay.addStretch()

        self.stt_pill = QLabel("Vosk: starting…")
        self.stt_pill.setStyleSheet("color:#9aa7b4; font-size:11px;")
        lay.addWidget(self.stt_pill)

        # Screen-capture protection status; updated by Copilot.apply_capture_protection.
        self.shield = QLabel("🛡 …")
        self.shield.setStyleSheet("color:#9aa7b4; font-size:11px;")
        lay.addWidget(self.shield)

        for txt, slot, hover, tip in (
                ("—", win.toggle_collapse, "#33507a", "Collapse to the title bar (click again to expand)"),
                ("▢", win.toggle_max, "#33507a", "Maximize / restore"),
                ("✕", win.close, "#c0392b", "Close")):
            b = QPushButton(txt)
            b.setFixedSize(30, 26)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            b.setStyleSheet(
                "QPushButton{background:rgba(255,255,255,20); color:#dfe7ef; border:none; "
                "border-radius:6px; font-size:13px;}"
                f"QPushButton:hover{{background:{hover}; color:white;}}")
            lay.addWidget(b)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.globalPosition().toPoint() - self._win.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag and not self._win.isMaximized():
            self._win.move(e.globalPosition().toPoint() - self._drag)

    def mouseDoubleClickEvent(self, e):
        # If collapsed, a double-click expands (restores) rather than maximizing
        # into an empty bar; otherwise it toggles maximize as usual.
        if getattr(self._win, "_collapsed", False):
            self._win.toggle_collapse()
        else:
            self._win.toggle_max()


# --------------------------------------------------------------------------- #
#  MAIN WINDOW                                                                 #
# --------------------------------------------------------------------------- #
class Copilot(QMainWindow):
    def __init__(self):
        super().__init__()
        self.comm = Comm()
        self.knowledge = Knowledge()
        self.session_id = 0
        self.current_model = "Grok"
        self.answers = {m: "" for m in MODELS}
        self.listening = True
        self._pending = ""
        self._live_peak = 0
        self._ghost = False
        self._capture_status = None   # last-applied screen-capture protection level
        self._collapsed = False       # "minimized" to the title bar
        self._expanded_geom = None    # geometry to restore when un-collapsing
        self._warn_was_visible = False

        self._build_ui()
        self._wire()
        self._register_hotkeys()

        # Apply screen-capture exclusion now, while the window is still hidden, so
        # it is absent from any screen share before its very first frame is
        # composited (no one-frame leak). winId() forces the native handle so the
        # affinity is in force before the window is mapped.
        self.winId()
        self.apply_capture_protection()

        self.streamer = VoskStreamer(
            on_partial=lambda t: self.comm.partial.emit(t),
            on_final=lambda t: self.comm.final.emit(t),
            on_level=lambda p: self.comm.level.emit(p),
            on_error=lambda e: self.comm.stt_error.emit(e),
        )
        QTimer.singleShot(300, self._start_stt)

        self.meter_timer = QTimer(self)
        self.meter_timer.timeout.connect(self._update_meter)
        self.meter_timer.start(80)

    # ------------------------------------------------------------- UI ------ #
    def _build_ui(self):
        # Qt.Tool keeps the window out of the taskbar, Alt-Tab switcher and Task
        # View. WDA_EXCLUDEFROMCAPTURE hides the window's own pixels/thumbnails but
        # NOT those shell surfaces, so without Tool the app's PRESENCE (a taskbar
        # button / Alt-Tab tile) still leaks in a full-desktop screen share.
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint
                            | Qt.WindowType.WindowStaysOnTopHint
                            | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        root = QWidget()
        root.setObjectName("root")
        root.setStyleSheet("""
            #root { background: rgba(11,15,21,238); border: 1px solid rgba(120,160,200,110);
                    border-radius: 14px; }
            QLabel { color:#dfe7ef; font-family:'Segoe UI'; }
            QTextEdit, QTextBrowser { background: rgba(6,10,16,180); color:#e6edf3;
                    border:1px solid rgba(120,160,200,70); border-radius:10px;
                    font-family:'Segoe UI'; font-size:13px; padding:8px; }
            QLineEdit { background: rgba(6,10,16,200); color:#e6edf3;
                    border:1px solid rgba(120,160,200,90); border-radius:9px; padding:8px; font-size:13px; }
            QPushButton { background: rgba(22,30,42,200); color:#cfe0ee;
                    border:1px solid rgba(120,160,200,90); border-radius:8px; padding:6px 12px; }
            QPushButton:hover { background: rgba(45,66,98,220); }
        """)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.title_bar = TitleBar(self)
        outer.addWidget(self.title_bar)

        # Capture-protection warning banner (full width, below the title bar).
        # Hidden while fully protected; shown if the window is only blacked-out or
        # not protected at all, so you're never falsely reassured you're hidden.
        self.capture_warning = QLabel("")
        self.capture_warning.setWordWrap(True)
        self.capture_warning.hide()
        outer.addWidget(self.capture_warning)

        content = QWidget()
        cl = QVBoxLayout(content)
        cl.setContentsMargins(14, 8, 14, 12)
        cl.setSpacing(10)

        body = QHBoxLayout()
        body.setSpacing(10)

        left = QVBoxLayout()
        left.setSpacing(8)
        left.addWidget(self._label("LIVE TRANSCRIPT  ·  real-time"))
        self.transcript = QTextEdit()
        self.transcript.setReadOnly(True)
        self.transcript.setFixedHeight(92)
        self.transcript.setHtml("<span style='color:#7d8b99'>Listening… start speaking and the words appear here instantly.</span>")
        left.addWidget(self.transcript)
        left.addWidget(self._label("PREPARED Q&A  ·  auto-scrolls to the match"))
        self.qa = QTextBrowser()
        self.qa.setOpenExternalLinks(False)
        self.qa.setHtml(self.knowledge.build_html())
        left.addWidget(self.qa, 1)
        body.addLayout(left, 43)

        right = QVBoxLayout()
        right.setSpacing(8)
        tabrow = QHBoxLayout()
        tabrow.addWidget(self._label("LIVE AI ANSWER  ·  grounded in your prep doc"))
        tabrow.addStretch()
        self.model_btns = {}
        for m in MODELS:
            b = QPushButton(m)
            b.clicked.connect(lambda _, n=m: self.show_model(n))
            tabrow.addWidget(b)
            self.model_btns[m] = b
        right.addLayout(tabrow)
        self.answer = QTextBrowser()
        self.answer.setOpenExternalLinks(False)
        self.answer.setHtml("<span style='color:#7d8b99'>The answer streams here the moment a question is heard.</span>")
        right.addWidget(self.answer, 1)
        body.addLayout(right, 57)
        cl.addLayout(body, 1)

        footer = QHBoxLayout()
        self.manual = QLineEdit()
        self.manual.setPlaceholderText("Type a question to test, then Enter…")
        self.manual.returnPressed.connect(self._on_manual)
        footer.addWidget(self.manual, 1)
        hint = QLabel("Hold M = pause/resume   ·   Hold P = transparent   ·   "
                      "drag any edge to resize   ·   Ctrl+Alt+1/2/3 = model   ·   "
                      "Ctrl+Alt+H = hide/show   ·   Esc = quit")
        hint.setStyleSheet("color:#7d8b99; font-size:11px;")
        footer.addWidget(hint)
        cl.addLayout(footer)

        # Keep a handle so "minimize" can collapse the window to just the title bar
        # (a hidden widget is ignored by the layout, so the window shrinks to fit).
        self.content = content
        outer.addWidget(content, 1)

        # Wrap the styled panel in a resize frame: the RESIZE_GRIP-wide transparent
        # border on every side is a drag handle (left/right = horizontal arrows).
        frame = ResizableFrame(self)
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(RESIZE_GRIP, RESIZE_GRIP, RESIZE_GRIP, RESIZE_GRIP)
        fl.addWidget(root)
        self.setCentralWidget(frame)

        scr = QGuiApplication.primaryScreen().availableGeometry()
        w, h = int(scr.width() * 0.82), int(scr.height() * 0.82)
        self.resize(w, h)
        self.move(scr.x() + (scr.width() - w) // 2, scr.y() + (scr.height() - h) // 2)
        self.show_model("Grok")

    def _label(self, text):
        lbl = QLabel(text)
        lbl.setStyleSheet("color:#7fb2d6; font-size:11px; font-weight:700; letter-spacing:1px;")
        return lbl

    def toggle_max(self):
        self.showNormal() if self.isMaximized() else self.showMaximized()

    def toggle_collapse(self):
        # "Minimize" = collapse to just the title bar, which stays on-screen and
        # on-top. A Qt.Tool window has no taskbar button, so native minimize / a
        # full hide would strand it with no way back — collapsing never loses it.
        # Click "—" again (or the title bar) to expand to the previous size.
        if self.isMaximized():
            self.showNormal()
        self._collapsed = not self._collapsed
        if self._collapsed:
            self._expanded_geom = self.geometry()
            self._warn_was_visible = self.capture_warning.isVisible()
            self.content.hide()
            self.capture_warning.hide()
            # Pin the height to the title bar (+ the resize-frame grips) so the
            # window shrinks to a slim always-visible bar.
            bar_h = self.title_bar.height() + 2 * RESIZE_GRIP
            self.setFixedHeight(bar_h)
        else:
            # Release the height clamp set above, then restore the saved geometry.
            self.setMinimumHeight(0)
            self.setMaximumHeight(16777215)   # QWIDGETSIZE_MAX
            self.content.show()
            if self._warn_was_visible:
                self.capture_warning.show()
            if self._expanded_geom is not None:
                self.setGeometry(self._expanded_geom)
        # Collapsing/expanding must not drop capture protection.
        self.apply_capture_protection()

    def _toggle_visible(self):
        # GUI-thread slot for the Ctrl+Alt+H global hotkey (routed via comm.toggle_vis).
        # A full hide for quickly ducking the whole overlay; press again to bring back.
        if self.isVisible():
            self.hide()
        else:
            self.showNormal()
            self.raise_()
            self.activateWindow()

    # --------------------------------------------------- capture guard ----- #
    def apply_capture_protection(self):
        """Re-assert screen-capture exclusion (idempotent). Called before the first
        frame, on show, and on the meter timer so protection self-heals if the
        native window is ever recreated (which silently drops the affinity)."""
        status = exclude_from_capture(self)
        if status == self._capture_status:
            return
        self._capture_status = status
        shield = self.title_bar.shield
        if status == "excluded":
            print("Screen-share protection: ON (WDA_EXCLUDEFROMCAPTURE)")
            shield.setText("🛡 Hidden from capture")
            shield.setStyleSheet("color:#38e08b; font-size:11px; font-weight:600;")
            self.capture_warning.hide()
        elif status == "monitor":
            print("Screen-share protection: PARTIAL (WDA_MONITOR — blacked-out, not hidden)")
            shield.setText("🛡 Blacked-out only")
            shield.setStyleSheet("color:#e0b341; font-size:11px; font-weight:600;")
            self.capture_warning.setStyleSheet(
                "background: rgba(200,140,0,235); color: white; font-weight:700; "
                "padding: 6px 12px; font-size: 12px;")
            self.capture_warning.setText(
                "⚠ Partial protection: this Windows build can't fully hide the window — "
                "it appears as a solid BLACK BOX in screen captures (unreadable, but visible).")
            self.capture_warning.show()
        else:
            print("Screen-share protection: FAILED — window IS visible to screen capture!")
            shield.setText("⚠ Capturable")
            shield.setStyleSheet("color:#ff6b6b; font-size:11px; font-weight:700;")
            self.capture_warning.setStyleSheet(
                "background: rgba(200,0,0,235); color: white; font-weight:700; "
                "padding: 6px 12px; font-size: 12px;")
            self.capture_warning.setText(
                "⚠ Screen-capture protection FAILED — this window IS visible to screen "
                "sharing / recording. (Full hiding requires Windows 10 2004 or newer.)")
            self.capture_warning.show()

    def showEvent(self, e):
        # Re-assert in case the native handle changed between winId() and mapping.
        super().showEvent(e)
        self.apply_capture_protection()

    # ----------------------------------------------------------- wiring ---- #
    def _wire(self):
        self.comm.partial.connect(self._on_partial)
        self.comm.final.connect(self._on_final)
        self.comm.level.connect(lambda p: setattr(self, "_live_peak", p))
        self.comm.stt_error.connect(self._on_stt_error)
        self.comm.ai_started.connect(self._on_ai_started)
        self.comm.ai_chunk.connect(self._on_ai_chunk)
        self.comm.ai_error.connect(self._on_ai_error)
        self.comm.m_pressed.connect(self._on_m_pressed)
        self.comm.m_released.connect(self._on_m_released)
        self.comm.p_pressed.connect(self._on_p_pressed)
        self.comm.p_released.connect(self._on_p_released)
        # Global hotkeys fire on the `keyboard` hook thread; these signals hop the
        # work back onto the GUI thread so Qt widgets are never mutated off-thread.
        self.comm.switch_model.connect(self.show_model)
        self.comm.toggle_vis.connect(self._toggle_visible)

        self._fire_timer = QTimer(self)
        self._fire_timer.setSingleShot(True)
        self._fire_timer.setInterval(FIRE_DEBOUNCE_MS)
        self._fire_timer.timeout.connect(self._fire_pending)

        self._m_timer = QTimer(self)
        self._m_timer.setSingleShot(True)
        self._m_timer.setInterval(HOLD_MS)
        self._m_timer.timeout.connect(self._toggle_listen)
        self._m_down = False

        self._p_timer = QTimer(self)
        self._p_timer.setSingleShot(True)
        self._p_timer.setInterval(HOLD_MS)
        self._p_timer.timeout.connect(self._toggle_ghost)
        self._p_down = False

    def _register_hotkeys(self):
        keyboard.on_press_key("m", lambda e: self.comm.m_pressed.emit())
        keyboard.on_release_key("m", lambda e: self.comm.m_released.emit())
        keyboard.on_press_key("p", lambda e: self.comm.p_pressed.emit())
        keyboard.on_release_key("p", lambda e: self.comm.p_released.emit())
        keyboard.add_hotkey("ctrl+alt+1", lambda: self.comm.switch_model.emit("Grok"))
        keyboard.add_hotkey("ctrl+alt+2", lambda: self.comm.switch_model.emit("DeepSeek"))
        keyboard.add_hotkey("ctrl+alt+3", lambda: self.comm.switch_model.emit("Gemini"))
        keyboard.add_hotkey("ctrl+alt+h", lambda: self.comm.toggle_vis.emit())

    def _start_stt(self):
        self.streamer.start()
        self.title_bar.stt_pill.setText("Vosk: on-device")

    # -------------------------------------------------------- transcript --- #
    def _on_partial(self, text):
        if not self.listening:
            return
        base = self._pending + " " if self._pending else ""
        self.transcript.setHtml(
            f"<span style='color:#e6edf3'>{html.escape(base)}</span>"
            f"<span style='color:#8be9fd'>{html.escape(text)}</span>")

    def _on_final(self, text):
        if not self.listening:
            return
        self._pending = (self._pending + " " + text).strip()
        self.transcript.setHtml(f"<span style='color:#e6edf3'>{html.escape(self._pending)}</span>")
        self._fire_timer.start()      # (re)start debounce; groups multi-pause questions

    def _fire_pending(self):
        text = self._pending.strip()
        self._pending = ""
        if len(text.split()) < MIN_WORDS_TO_FIRE:
            return
        self.process(text)

    def _on_stt_error(self, msg):
        self.title_bar.stt_pill.setText("STT error")
        self.transcript.setHtml(
            f"<span style='color:#ff9d9d'>⚠ {html.escape(msg)}</span><br>"
            "<span style='color:#7d8b99'>You can still type questions in the box below.</span>")

    # ------------------------------------------------------- the pipeline -- #
    def process(self, text):
        self.session_id += 1
        sid = self.session_id
        self.answers = {m: "" for m in MODELS}
        self.transcript.setHtml(
            f"<span style='color:#7fb2d6; font-size:11px; font-weight:700;'>QUESTION</span><br>"
            f"<span style='color:#ffffff; font-size:14px;'>{html.escape(text)}</span>")

        idx, score = self.knowledge.match(text)
        if idx is not None:
            self.qa.setHtml(self.knowledge.build_html(active_idx=idx))
            QTimer.singleShot(30, lambda: self._scroll_to(f"q{idx}"))

        refs = self.knowledge.retrieve(text, k=3)
        ref_text = ""
        for r in refs:
            ref_text += f"\n\n[Q] {r['q']}\n[A] {r['a'][:1800]}"
            if r["code"]:
                ref_text += f"\n[CODE]\n{r['code']}"
        system = SYSTEM_PROMPT + ("\n\nREFERENCE ANSWERS FROM KIDUS'S NEUBERGER "
                                  "BERMAN PREP PLAYBOOK (ground your answer in these, "
                                  "match the voice):" + ref_text if ref_text else "")
        messages = [{"role": "system", "content": system}, {"role": "user", "content": text}]

        for m in MODELS:
            self.answers[m] = ""
            threading.Thread(target=self._ai_worker, args=(sid, m, messages), daemon=True).start()
        self.show_model(self.current_model)

    def _ai_worker(self, sid, model, messages):
        self.comm.ai_started.emit(sid, model)
        try:
            for chunk in AI_FUNCS[model](messages):
                if sid != self.session_id:
                    return
                self.comm.ai_chunk.emit(sid, model, chunk)
        except Exception as e:
            self.comm.ai_error.emit(sid, model, str(e))

    def _on_ai_started(self, sid, model):
        if sid == self.session_id and model == self.current_model:
            self.answer.setHtml("<span style='color:#7d8b99'>…thinking…</span>")

    def _on_ai_chunk(self, sid, model, chunk):
        if sid != self.session_id:
            return
        self.answers[model] += chunk
        if model == self.current_model:
            self._render_answer(self.answers[model])

    def _on_ai_error(self, sid, model, msg):
        if sid != self.session_id:
            return
        self.answers[model] = f"**[{model} error]** {msg}"
        if model == self.current_model:
            self._render_answer(self.answers[model])

    def _render_answer(self, md):
        sb = self.answer.verticalScrollBar()
        at_bottom = sb.value() >= sb.maximum() - 40
        self.answer.setHtml(render_markdown(md))
        if at_bottom:
            sb.setValue(sb.maximum())

    # ------------------------------------------------------------ misc ----- #
    def _scroll_to(self, anchor):
        sb = self.qa.verticalScrollBar()
        old = sb.value()
        self.qa.scrollToAnchor(anchor)
        target = sb.value()
        sb.setValue(old)
        self._anim = QPropertyAnimation(sb, b"value")
        self._anim.setDuration(450)
        self._anim.setStartValue(old)
        self._anim.setEndValue(target)
        self._anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self._anim.start()

    def show_model(self, name):
        self.current_model = name
        for m, b in self.model_btns.items():
            active = (m == name)
            b.setStyleSheet(
                ("background: rgba(60,120,200,230); color:white; border:1px solid #8be9fd;"
                 if active else
                 "background: rgba(22,30,42,200); color:#cfe0ee; border:1px solid rgba(120,160,200,90);")
                + " border-radius:8px; padding:6px 12px;")
        md = self.answers.get(name)
        self.answer.setHtml(render_markdown(md) if md else
                            "<span style='color:#7d8b99'>The answer streams here the moment a question is heard.</span>")

    def _on_manual(self):
        t = self.manual.text().strip()
        if t:
            self.manual.clear()
            self._pending = ""
            self.process(t)

    def _update_meter(self):
        # Self-heal: cheaply re-assert screen-capture exclusion every tick in case
        # the native window was recreated (which would silently drop the affinity).
        self.apply_capture_protection()
        if not self.listening:
            self.title_bar.meter.setText("‖ paused")
            self.title_bar.meter.setStyleSheet("color:#e0b341; font-size:12px;")
            return
        level = min(7, int(self._live_peak / 1200))
        bar = "".join("█" if i < level else "▁" for i in range(7))
        self.title_bar.meter.setText(bar)
        self.title_bar.meter.setStyleSheet(
            f"color:{'#38e08b' if level else '#3a4652'}; font-size:12px;")

    # ------------------------------------------------------- M pause/resume - #
    def _on_m_pressed(self):
        if self._m_down:
            return
        self._m_down = True
        self._m_timer.start()

    def _on_m_released(self):
        self._m_down = False
        self._m_timer.stop()

    def _toggle_listen(self):
        if not self._m_down:
            return
        self.listening = not self.listening
        self.streamer.set_paused(not self.listening)
        if self.listening:
            self.title_bar.status.setText("● LIVE")
            self.title_bar.status.setStyleSheet("color:#38e08b; font-size:12px; font-weight:600;")
        else:
            # Pausing must NOT touch the AI — a slow model (e.g. Gemini) keeps
            # streaming. It only stops the pipeline from ADVANCING: kill the
            # pending debounce and drop the buffered speech so no new question
            # fires (a new process() would bump session_id and abort the answer
            # still streaming). This is the whole point of hitting M after a
            # question — "hold here, let the current answer finish."
            self._fire_timer.stop()
            self._pending = ""
            self.title_bar.status.setText("‖ PAUSED")
            self.title_bar.status.setStyleSheet("color:#e0b341; font-size:12px; font-weight:600;")

    # ------------------------------------------------- P transparency ------ #
    def _on_p_pressed(self):
        if self._p_down:
            return
        self._p_down = True
        self._p_timer.start()

    def _on_p_released(self):
        self._p_down = False
        self._p_timer.stop()

    def _toggle_ghost(self):
        if not self._p_down:
            return
        self._ghost = not self._ghost
        self.setWindowOpacity(GHOST_OPACITY if self._ghost else 1.0)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.close()

    def closeEvent(self, e):
        try:
            self.streamer.stop()
            keyboard.unhook_all()
        except Exception:
            pass
        e.accept()


def main():
    app = QApplication(sys.argv)
    win = Copilot()
    win.show()
    return app.exec()


def _supervise():
    """Run the app as a child process and relaunch it if it crashes."""
    import subprocess
    import time
    fails = 0
    while True:
        started = time.monotonic()
        rc = subprocess.run([sys.executable, os.path.abspath(__file__), "--child"]).returncode
        if rc == 0:
            break  # clean exit (user closed / Esc)
        ran = time.monotonic() - started
        fails = fails + 1 if ran < 5 else 0
        if fails >= 5:
            print("Neuberger Copilot crashed 5x in a row — stopping. See the error above.")
            break
        print(f"\n⚠ Neuberger Copilot exited (code {rc}); restarting…\n")


if __name__ == "__main__":
    if "--child" in sys.argv:
        import traceback
        try:
            sys.exit(main())
        except Exception:
            traceback.print_exc()
            sys.exit(1)
    else:
        _supervise()
